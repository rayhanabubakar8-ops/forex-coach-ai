import { Router, type Request, type Response } from "express";
import { getCoachAdvice } from "../lib/coach";
import { getUser } from "../lib/subscriptionStore";
import {
  createTrade,
  deleteTrade,
  getAnalytics,
  listTrades,
  type NewTradeInput,
} from "../lib/tradeStore";

const router = Router();
const pairsPattern = /^[A-Z]{3,6}$/;

function readUserId(req: Request): string | null {
  const bodyUserId = req.body?.userId;
  const queryUserId = req.query["userId"];
  const userId =
    typeof bodyUserId === "string"
      ? bodyUserId
      : typeof queryUserId === "string"
        ? queryUserId
        : null;
  return userId?.trim() || null;
}

function validateTrade(body: Record<string, unknown>): NewTradeInput {
  const userId = typeof body.userId === "string" ? body.userId.trim() : "";
  const pair = typeof body.pair === "string" ? body.pair.trim().toUpperCase() : "";
  const entryPrice = typeof body.entryPrice === "string" ? body.entryPrice.trim() : "";
  const stopLoss = typeof body.stopLoss === "string" ? body.stopLoss.trim() : "";
  const takeProfit = typeof body.takeProfit === "string" ? body.takeProfit.trim() : "";
  const lotSize = typeof body.lotSize === "string" ? body.lotSize.trim() : "";
  const result = body.result === "loss" ? "loss" : body.result === "win" ? "win" : null;
  const session =
    body.session === "Asia" || body.session === "London" || body.session === "New York"
      ? body.session
      : null;
  const notes = typeof body.notes === "string" ? body.notes : "";

  if (!userId) throw new Error("userId is required.");
  if (!pair || !pairsPattern.test(pair)) throw new Error("A valid pair is required.");
  if (!entryPrice || Number.isNaN(Number(entryPrice))) throw new Error("A valid entry price is required.");
  if (!stopLoss || Number.isNaN(Number(stopLoss))) throw new Error("A valid stop loss is required.");
  if (!takeProfit || Number.isNaN(Number(takeProfit))) throw new Error("A valid take profit is required.");
  if (!lotSize || Number.isNaN(Number(lotSize))) throw new Error("A valid lot size is required.");
  if (!result) throw new Error("Result must be win or loss.");
  if (!session) throw new Error("Session must be Asia, London, or New York.");

  return {
    userId,
    pair,
    entryPrice,
    stopLoss,
    takeProfit,
    lotSize,
    result,
    session,
    notes,
  };
}

router.post("/add_trade", (req: Request, res: Response) => {
  try {
    const trade = createTrade(validateTrade(req.body ?? {}));
    res.status(201).json({ trade });
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Unable to add trade.",
    });
  }
});

router.get("/get_trades", (req: Request, res: Response) => {
  const userId = readUserId(req);
  if (!userId) {
    res.status(400).json({ error: "userId is required." });
    return;
  }
  res.json({ trades: listTrades(userId) });
});

router.delete("/delete_trade/:id", (req: Request, res: Response) => {
  const userId = readUserId(req);
  const tradeId = req.params.id;
  if (!userId) {
    res.status(400).json({ error: "userId is required." });
    return;
  }
  const deleted = deleteTrade(userId, tradeId);
  res.json({ deleted });
});

router.get("/analytics", async (req: Request, res: Response) => {
  const userId = readUserId(req);
  if (!userId) {
    res.status(400).json({ error: "userId is required." });
    return;
  }
  try {
    const analytics = getAnalytics(userId);
    const user = getUser(userId);
    const isPremium = user?.plan === "premium";
    const coach = isPremium
      ? await getCoachAdvice(analytics.trades)
      : {
          analysis:
            "Free users receive basic journal analytics. Upgrade to Premium to unlock unlimited AI coach reviews.",
          mistakes: ["Upgrade to Premium to unlock this feature"],
          rule: "Log every trade and review your win rate until Premium AI coaching is unlocked.",
          source: "rules" as const,
        };
    res.json({ ...analytics, coach });
  } catch (error) {
    req.log.error({ err: error }, "Unable to load analytics");
    res.status(500).json({ error: "Unable to load analytics." });
  }
});

export default router;
