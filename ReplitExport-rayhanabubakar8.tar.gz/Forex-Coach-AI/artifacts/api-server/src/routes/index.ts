import { Router, type IRouter } from "express";
import accountsRouter from "./accounts";
import healthRouter from "./health";
import subscriptionsRouter from "./subscriptions";
import tradesRouter from "./trades";

const router: IRouter = Router();

router.use(healthRouter);
router.use(subscriptionsRouter);
router.use(accountsRouter);
router.use(tradesRouter);

export default router;
