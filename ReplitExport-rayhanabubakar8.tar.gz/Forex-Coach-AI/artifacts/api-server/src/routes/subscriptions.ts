import { Router, type Request, type Response } from "express";
import {
  getPaymentAddress,
  getUser,
  listPayments,
  submitPayment,
  upgradeUser,
  upsertUser,
  verifyPayment,
  type UserPlan,
} from "../lib/subscriptionStore";

const router = Router();

function readString(value: unknown, field: string): string {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`${field} is required.`);
  }
  return value.trim();
}

function readAmount(value: unknown): number {
  const amount = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(amount) || amount <= 0) {
    throw new Error("amount must be a positive number.");
  }
  return amount;
}

router.get("/payment_instructions", (_req: Request, res: Response) => {
  res.json(getPaymentAddress());
});

router.post("/sync_user", (req: Request, res: Response) => {
  try {
    const plan: UserPlan = req.body?.plan === "premium" ? "premium" : "free";
    const user = upsertUser({
      id: readString(req.body?.id, "id"),
      name: readString(req.body?.name, "name"),
      email: readString(req.body?.email, "email"),
      plan,
      createdAt: typeof req.body?.createdAt === "string" ? req.body.createdAt : undefined,
    });
    res.json({ user });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Unable to sync user." });
  }
});

router.get("/user/:userId", (req: Request, res: Response) => {
  const user = getUser(req.params.userId);
  if (!user) {
    res.status(404).json({ error: "User not found." });
    return;
  }
  res.json({ user });
});

router.post("/submit_payment", (req: Request, res: Response) => {
  try {
    const payment = submitPayment({
      userId: readString(req.body?.userId ?? req.body?.user_id, "userId"),
      txid: readString(req.body?.txid ?? req.body?.TXID, "txid"),
      amount: readAmount(req.body?.amount),
    });
    res.status(201).json({ message: "Payment submitted for manual review", payment });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Unable to submit payment." });
  }
});

router.get("/payments", (req: Request, res: Response) => {
  const userId = typeof req.query.userId === "string" ? req.query.userId : undefined;
  res.json({ payments: listPayments(userId) });
});

router.post("/verify_payment", (req: Request, res: Response) => {
  try {
    const paymentId = Number(req.body?.paymentId ?? req.body?.payment_id);
    if (!Number.isInteger(paymentId) || paymentId <= 0) {
      throw new Error("paymentId must be a valid payment id.");
    }
    const approved = req.body?.approved === true || req.body?.status === "approved";
    const payment = verifyPayment(paymentId, approved);
    const user = getUser(payment.userId);
    res.json({ message: approved ? "Payment approved" : "Payment rejected", payment, user });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Unable to verify payment." });
  }
});

router.post("/upgrade_user", (req: Request, res: Response) => {
  try {
    const user = upgradeUser(readString(req.body?.userId ?? req.body?.user_id, "userId"));
    res.json({ message: "User upgraded to premium", user });
  } catch (error) {
    res.status(400).json({ error: error instanceof Error ? error.message : "Unable to upgrade user." });
  }
});

export default router;
