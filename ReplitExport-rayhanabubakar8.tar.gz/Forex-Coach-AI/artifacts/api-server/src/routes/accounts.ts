import { Router, type Request, type Response } from "express";
import {
  addAccountTrade,
  createAccount,
  getAccountAnalytics,
  listAccounts,
  listAccountTrades,
  type NewAccountInput,
  type NewAccountTradeInput,
} from "../lib/accountStore";

const router = Router();
const pairsPattern = /^[A-Z]{3,6}$/;

function readNumber(value: unknown, field: string): number {
  const parsed = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(parsed)) {
    throw new Error(`${field} must be a valid number.`);
  }
  return parsed;
}

function validateAccount(body: Record<string, unknown>): NewAccountInput {
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const type = body.type === "prop" ? "prop" : body.type === "personal" ? "personal" : null;
  const balance = readNumber(body.balance, "balance");
  const dailyLossLimit = readNumber(body.daily_loss_limit ?? body.dailyLossLimit, "daily_loss_limit");
  const maxDrawdown = readNumber(body.max_drawdown ?? body.maxDrawdown, "max_drawdown");
  const profitTarget = readNumber(body.profit_target ?? body.profitTarget, "profit_target");

  if (!name) throw new Error("name is required.");
  if (!type) throw new Error("type must be personal or prop.");
  if (balance < 0) throw new Error("balance cannot be negative.");
  if (dailyLossLimit < 0) throw new Error("daily_loss_limit cannot be negative.");
  if (maxDrawdown < 0) throw new Error("max_drawdown cannot be negative.");
  if (profitTarget < 0) throw new Error("profit_target cannot be negative.");

  return { name, type, balance, dailyLossLimit, maxDrawdown, profitTarget };
}

function validateAccountTrade(body: Record<string, unknown>): NewAccountTradeInput {
  const accountId = readNumber(body.account_id ?? body.accountId, "account_id");
  const pair = typeof body.pair === "string" ? body.pair.trim().toUpperCase() : "";
  const pnl = readNumber(body.pnl, "pnl");

  if (!Number.isInteger(accountId) || accountId <= 0) {
    throw new Error("account_id must be a valid account id.");
  }
  if (!pair || !pairsPattern.test(pair)) {
    throw new Error("pair must be a valid forex pair.");
  }

  return { accountId, pair, pnl };
}

router.post("/create_account", (req: Request, res: Response) => {
  try {
    const account = createAccount(validateAccount(req.body ?? {}));
    res.status(201).json({ message: "Account created successfully", account });
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Unable to create account.",
    });
  }
});

router.get("/accounts", (_req: Request, res: Response) => {
  res.json({ accounts: listAccounts() });
});

router.post("/add_account_trade", (req: Request, res: Response) => {
  try {
    const trade = addAccountTrade(validateAccountTrade(req.body ?? {}));
    res.status(201).json({ message: "Trade added", trade });
  } catch (error) {
    res.status(400).json({
      error: error instanceof Error ? error.message : "Unable to add account trade.",
    });
  }
});

router.get("/account_trades/:accountId", (req: Request, res: Response) => {
  const accountId = Number(req.params.accountId);
  if (!Number.isInteger(accountId) || accountId <= 0) {
    res.status(400).json({ error: "accountId must be a valid account id." });
    return;
  }
  res.json({ trades: listAccountTrades(accountId) });
});

router.get("/analytics/:accountId", (req: Request, res: Response) => {
  try {
    const accountId = Number(req.params.accountId);
    if (!Number.isInteger(accountId) || accountId <= 0) {
      res.status(400).json({ error: "accountId must be a valid account id." });
      return;
    }
    res.json(getAccountAnalytics(accountId));
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unable to load account analytics.";
    res.status(message === "Account not found." ? 404 : 500).json({ error: message });
  }
});

export default router;
