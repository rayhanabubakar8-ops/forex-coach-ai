import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

export interface AccountRecord {
  id: number;
  name: string;
  type: "personal" | "prop";
  balance: number;
  dailyLossLimit: number;
  maxDrawdown: number;
  profitTarget: number;
}

export interface AccountTradeRecord {
  id: number;
  accountId: number;
  pair: string;
  pnl: number;
  date: string;
}

export interface NewAccountInput {
  name: string;
  type: "personal" | "prop";
  balance: number;
  dailyLossLimit: number;
  maxDrawdown: number;
  profitTarget: number;
}

export interface NewAccountTradeInput {
  accountId: number;
  pair: string;
  pnl: number;
}

export interface AccountAnalytics {
  account: AccountRecord;
  balance: number;
  equity: number;
  total_pnl: number;
  daily_pnl: number;
  drawdown: number;
  status: "SAFE" | "DAILY LOSS LIMIT HIT" | "MAX DRAWDOWN HIT" | "TARGET REACHED";
}

const dataDir = path.resolve(process.cwd(), "data");
mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "trademind.sqlite"));

db.exec(`
  CREATE TABLE IF NOT EXISTS accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK(type IN ('personal', 'prop')),
    balance REAL NOT NULL,
    daily_loss_limit REAL NOT NULL,
    max_drawdown REAL NOT NULL,
    profit_target REAL NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS account_trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id INTEGER NOT NULL,
    pair TEXT NOT NULL,
    pnl REAL NOT NULL,
    date TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_account_trades_account_date ON account_trades(account_id, date DESC);
`);

function mapAccount(row: Record<string, unknown>): AccountRecord {
  return {
    id: Number(row.id),
    name: String(row.name),
    type: row.type === "prop" ? "prop" : "personal",
    balance: Number(row.balance),
    dailyLossLimit: Number(row.daily_loss_limit),
    maxDrawdown: Number(row.max_drawdown),
    profitTarget: Number(row.profit_target),
  };
}

function mapAccountTrade(row: Record<string, unknown>): AccountTradeRecord {
  return {
    id: Number(row.id),
    accountId: Number(row.account_id),
    pair: String(row.pair),
    pnl: Number(row.pnl),
    date: String(row.date),
  };
}

export function createAccount(input: NewAccountInput): AccountRecord {
  const result = db
    .prepare(
      `INSERT INTO accounts (
        name,
        type,
        balance,
        daily_loss_limit,
        max_drawdown,
        profit_target,
        created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(
      input.name.trim(),
      input.type,
      input.balance,
      input.dailyLossLimit,
      input.maxDrawdown,
      input.profitTarget,
      new Date().toISOString(),
    );

  const row = db
    .prepare("SELECT * FROM accounts WHERE id = ?")
    .get(result.lastInsertRowid) as Record<string, unknown> | undefined;

  if (!row) throw new Error("Account was not created.");
  return mapAccount(row);
}

export function listAccounts(): AccountRecord[] {
  const rows = db
    .prepare("SELECT * FROM accounts ORDER BY created_at DESC")
    .all() as Record<string, unknown>[];
  return rows.map(mapAccount);
}

export function getAccount(accountId: number): AccountRecord | null {
  const row = db
    .prepare("SELECT * FROM accounts WHERE id = ?")
    .get(accountId) as Record<string, unknown> | undefined;
  return row ? mapAccount(row) : null;
}

export function addAccountTrade(input: NewAccountTradeInput): AccountTradeRecord {
  const account = getAccount(input.accountId);
  if (!account) throw new Error("Account not found.");

  const date = new Date().toISOString().slice(0, 10);
  const result = db
    .prepare(
      `INSERT INTO account_trades (account_id, pair, pnl, date, created_at)
       VALUES (?, ?, ?, ?, ?)`,
    )
    .run(
      input.accountId,
      input.pair.trim().toUpperCase(),
      input.pnl,
      date,
      new Date().toISOString(),
    );

  const row = db
    .prepare("SELECT * FROM account_trades WHERE id = ?")
    .get(result.lastInsertRowid) as Record<string, unknown> | undefined;

  if (!row) throw new Error("Trade was not created.");
  return mapAccountTrade(row);
}

export function listAccountTrades(accountId: number): AccountTradeRecord[] {
  const rows = db
    .prepare("SELECT * FROM account_trades WHERE account_id = ? ORDER BY date DESC, id DESC")
    .all(accountId) as Record<string, unknown>[];
  return rows.map(mapAccountTrade);
}

export function getAccountAnalytics(accountId: number): AccountAnalytics {
  const account = getAccount(accountId);
  if (!account) throw new Error("Account not found.");

  const trades = listAccountTrades(accountId);
  const totalPnl = trades.reduce((sum, trade) => sum + trade.pnl, 0);
  const today = new Date().toISOString().slice(0, 10);
  const dailyPnl = trades
    .filter((trade) => trade.date === today)
    .reduce((sum, trade) => sum + trade.pnl, 0);
  const equity = account.balance + totalPnl;
  const drawdown = Math.max(0, account.balance - equity);

  let status: AccountAnalytics["status"] = "SAFE";
  if (dailyPnl < -account.dailyLossLimit) {
    status = "DAILY LOSS LIMIT HIT";
  }
  if (drawdown > account.maxDrawdown) {
    status = "MAX DRAWDOWN HIT";
  }
  if (equity >= account.balance + account.profitTarget) {
    status = "TARGET REACHED";
  }

  return {
    account,
    balance: account.balance,
    equity,
    total_pnl: totalPnl,
    daily_pnl: dailyPnl,
    drawdown,
    status,
  };
}
