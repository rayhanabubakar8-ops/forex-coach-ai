import type { TradeRecord } from "./tradeStore";

export interface CoachAdvice {
  analysis: string;
  mistakes: string[];
  rule: string;
  source: "openai" | "rules";
}

function getRuleBasedAdvice(trades: TradeRecord[]): CoachAdvice {
  if (trades.length === 0) {
    return {
      analysis:
        "You have not logged any trades yet. Start journaling every setup so the system can detect your habits and weaknesses.",
      mistakes: ["No trade data available for analysis."],
      rule: "Log your next 5 trades with entry, stop loss, take profit, session, and notes before judging your strategy.",
      source: "rules",
    };
  }

  const total = trades.length;
  const wins = trades.filter((trade) => trade.result === "win").length;
  const winRate = Math.round((wins / total) * 100);
  const today = new Date().toDateString();
  const tradesToday = trades.filter(
    (trade) => new Date(trade.date).toDateString() === today,
  ).length;
  const rrValues = trades.map((trade) => {
    const entry = Number(trade.entryPrice);
    const stopLoss = Number(trade.stopLoss);
    const takeProfit = Number(trade.takeProfit);
    const risk = Math.abs(entry - stopLoss);
    const reward = Math.abs(takeProfit - entry);
    return risk > 0 ? reward / risk : 0;
  });
  const averageRr =
    rrValues.length > 0
      ? rrValues.reduce((sum, value) => sum + value, 0) / rrValues.length
      : 0;

  const mistakes: string[] = [];
  if (tradesToday > 3) {
    mistakes.push(
      `Overtrading detected: ${tradesToday} trades today. Your decision quality drops when frequency rises.`,
    );
  }
  if (averageRr < 1.5) {
    mistakes.push(
      `Low average risk-to-reward: ${averageRr.toFixed(1)}:1. You are not being paid enough for the risk taken.`,
    );
  }
  if (winRate < 40 && total >= 5) {
    mistakes.push(
      `Weak win rate: ${winRate}%. Your entry criteria are not selective enough.`,
    );
  }
  if (trades.filter((trade) => !trade.notes.trim()).length > total / 2) {
    mistakes.push(
      "Too many trades have no notes. If you cannot explain the trade, you should not take it.",
    );
  }
  if (mistakes.length === 0) {
    mistakes.push(
      "No major discipline issue detected yet. Keep collecting data and avoid increasing risk after wins.",
    );
  }

  return {
    analysis: `You logged ${total} trades with a ${winRate}% win rate and ${averageRr.toFixed(1)}:1 average risk-to-reward. The data shows whether you are trading with discipline, not hope.`,
    mistakes,
    rule:
      averageRr < 1.5
        ? "For the next 10 trades, take only setups with at least 2:1 reward-to-risk. Skip everything else."
        : "For the next week, limit yourself to two planned trades per day and write the reason before entry.",
    source: "rules",
  };
}

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  try {
    return JSON.parse(trimmed);
  } catch {
    const match = trimmed.match(/\{[\s\S]*\}/);
    if (!match) throw new Error("AI response did not contain JSON.");
    return JSON.parse(match[0]);
  }
}

function normalizeAdvice(value: unknown): CoachAdvice {
  if (!value || typeof value !== "object") {
    throw new Error("Invalid AI advice response.");
  }
  const data = value as Record<string, unknown>;
  const mistakes = Array.isArray(data.mistakes)
    ? data.mistakes.map(String).filter(Boolean).slice(0, 5)
    : [];
  return {
    analysis:
      typeof data.analysis === "string" && data.analysis.trim()
        ? data.analysis.trim()
        : "Your trading data was reviewed, but the AI response was incomplete.",
    mistakes:
      mistakes.length > 0
        ? mistakes
        : ["No specific mistake was returned by the AI coach."],
    rule:
      typeof data.rule === "string" && data.rule.trim()
        ? data.rule.trim()
        : "Take only trades that match your written plan.",
    source: "openai",
  };
}

export async function getCoachAdvice(
  trades: TradeRecord[],
): Promise<CoachAdvice> {
  if (trades.length === 0) {
    return getRuleBasedAdvice(trades);
  }

  const baseUrl = process.env["AI_INTEGRATIONS_OPENAI_BASE_URL"];
  const apiKey = process.env["AI_INTEGRATIONS_OPENAI_API_KEY"];

  if (!baseUrl || !apiKey) {
    return getRuleBasedAdvice(trades);
  }

  try {
    const compactTrades = trades.slice(0, 30).map((trade) => ({
      pair: trade.pair,
      entryPrice: trade.entryPrice,
      stopLoss: trade.stopLoss,
      takeProfit: trade.takeProfit,
      lotSize: trade.lotSize,
      result: trade.result,
      session: trade.session,
      notes: trade.notes,
      date: trade.date,
    }));

    const response = await fetch(`${baseUrl.replace(/\/$/, "")}/chat/completions`, {
      method: "POST",
      signal: AbortSignal.timeout(4500),
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-5.2",
        max_completion_tokens: 700,
        messages: [
          {
            role: "system",
            content:
              "You are TradeMind AI, a strict forex trading coach. Analyze journal data, detect discipline mistakes like overtrading, low risk-to-reward, weak journaling, revenge trading, and poor session selection. Return only valid JSON with keys: analysis (string), mistakes (array of strings), rule (one strict improvement rule). Do not include markdown.",
          },
          {
            role: "user",
            content: JSON.stringify({ trades: compactTrades }),
          },
        ],
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI request failed: ${response.status}`);
    }

    const result = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const content = result.choices?.[0]?.message?.content;
    if (!content) {
      throw new Error("OpenAI returned no coaching content.");
    }
    return normalizeAdvice(extractJson(content));
  } catch {
    return getRuleBasedAdvice(trades);
  }
}
