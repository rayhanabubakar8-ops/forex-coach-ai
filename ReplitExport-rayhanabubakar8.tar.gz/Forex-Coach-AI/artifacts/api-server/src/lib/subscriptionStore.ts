import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

export type UserPlan = "free" | "premium";
export type PaymentStatus = "pending" | "approved" | "rejected";

export interface AppUserRecord {
  id: string;
  name: string;
  email: string;
  plan: UserPlan;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentRecord {
  id: number;
  userId: string;
  txid: string;
  amount: number;
  network: string;
  address: string;
  status: PaymentStatus;
  submittedAt: string;
  verifiedAt: string | null;
}

export interface UpsertUserInput {
  id: string;
  name: string;
  email: string;
  plan?: UserPlan;
  createdAt?: string;
}

export interface SubmitPaymentInput {
  userId: string;
  txid: string;
  amount: number;
}

const dataDir = path.resolve(process.cwd(), "data");
mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "trademind.sqlite"));
const bybitAddress = process.env["BYBIT_USDT_ADDRESS"] || "YOUR_BYBIT_USDT_ADDRESS";

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    plan TEXT NOT NULL DEFAULT 'free' CHECK(plan IN ('free', 'premium')),
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    txid TEXT NOT NULL,
    amount REAL NOT NULL,
    network TEXT NOT NULL DEFAULT 'TRC20',
    address TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending', 'approved', 'rejected')),
    submitted_at TEXT NOT NULL,
    verified_at TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_payments_user_status ON payments(user_id, status);
`);

function mapUser(row: Record<string, unknown>): AppUserRecord {
  return {
    id: String(row.id),
    name: String(row.name),
    email: String(row.email),
    plan: row.plan === "premium" ? "premium" : "free",
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function mapPayment(row: Record<string, unknown>): PaymentRecord {
  return {
    id: Number(row.id),
    userId: String(row.user_id),
    txid: String(row.txid),
    amount: Number(row.amount),
    network: String(row.network),
    address: String(row.address),
    status:
      row.status === "approved"
        ? "approved"
        : row.status === "rejected"
          ? "rejected"
          : "pending",
    submittedAt: String(row.submitted_at),
    verifiedAt: row.verified_at ? String(row.verified_at) : null,
  };
}

export function getPaymentAddress() {
  return {
    network: "TRC20",
    address: bybitAddress,
  };
}

export function upsertUser(input: UpsertUserInput): AppUserRecord {
  const now = new Date().toISOString();
  const createdAt = input.createdAt || now;
  const plan = input.plan === "premium" ? "premium" : "free";

  db.prepare(
    `INSERT INTO users (id, name, email, plan, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       name = excluded.name,
       email = excluded.email,
       plan = CASE WHEN users.plan = 'premium' THEN 'premium' ELSE excluded.plan END,
       updated_at = excluded.updated_at`,
  ).run(input.id, input.name.trim(), input.email.trim().toLowerCase(), plan, createdAt, now);

  const user = getUser(input.id);
  if (!user) throw new Error("User was not saved.");
  return user;
}

export function getUser(userId: string): AppUserRecord | null {
  const row = db
    .prepare("SELECT * FROM users WHERE id = ?")
    .get(userId) as Record<string, unknown> | undefined;
  return row ? mapUser(row) : null;
}

export function listPayments(userId?: string): PaymentRecord[] {
  const rows = userId
    ? (db
        .prepare("SELECT * FROM payments WHERE user_id = ? ORDER BY submitted_at DESC")
        .all(userId) as Record<string, unknown>[])
    : (db
        .prepare("SELECT * FROM payments ORDER BY submitted_at DESC")
        .all() as Record<string, unknown>[]);
  return rows.map(mapPayment);
}

export function submitPayment(input: SubmitPaymentInput): PaymentRecord {
  if (!getUser(input.userId)) {
    throw new Error("User not found. Create or sync the user before submitting payment.");
  }

  const result = db.prepare(
    `INSERT INTO payments (user_id, txid, amount, network, address, status, submitted_at)
     VALUES (?, ?, ?, 'TRC20', ?, 'pending', ?)`,
  ).run(input.userId, input.txid.trim(), input.amount, bybitAddress, new Date().toISOString());

  const row = db
    .prepare("SELECT * FROM payments WHERE id = ?")
    .get(result.lastInsertRowid) as Record<string, unknown> | undefined;
  if (!row) throw new Error("Payment was not saved.");
  return mapPayment(row);
}

export function upgradeUser(userId: string): AppUserRecord {
  const result = db
    .prepare("UPDATE users SET plan = 'premium', updated_at = ? WHERE id = ?")
    .run(new Date().toISOString(), userId);
  if (result.changes === 0) throw new Error("User not found.");
  const user = getUser(userId);
  if (!user) throw new Error("User not found.");
  return user;
}

export function verifyPayment(paymentId: number, approved: boolean): PaymentRecord {
  const payment = db
    .prepare("SELECT * FROM payments WHERE id = ?")
    .get(paymentId) as Record<string, unknown> | undefined;
  if (!payment) throw new Error("Payment not found.");

  const status: PaymentStatus = approved ? "approved" : "rejected";
  db.prepare("UPDATE payments SET status = ?, verified_at = ? WHERE id = ?").run(
    status,
    new Date().toISOString(),
    paymentId,
  );

  const updated = db
    .prepare("SELECT * FROM payments WHERE id = ?")
    .get(paymentId) as Record<string, unknown> | undefined;
  if (!updated) throw new Error("Payment not found.");

  const mapped = mapPayment(updated);
  if (approved) {
    upgradeUser(mapped.userId);
  }
  return mapped;
}
