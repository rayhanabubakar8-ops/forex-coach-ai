import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";

export interface TradeRecord {
  id: string;
  userId: string;
  pair: string;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  lotSize: string;
  result: "win" | "loss";
  session: "Asia" | "London" | "New York";
  notes: string;
  date: string;
}

export interface NewTradeInput {
  userId: string;
  pair: string;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  lotSize: string;
  result: "win" | "loss";
  session: "Asia" | "London" | "New York";
  notes?: string;
}

const dataDir = path.resolve(process.cwd(), "data");
mkdirSync(dataDir, { recursive: true });

const db = new DatabaseSync(path.join(dataDir, "trademind.sqlite"));

db.exec(`
  CREATE TABLE IF NOT EXISTS trades (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    pair TEXT NOT NULL,
    entry_price TEXT NOT NULL,
    stop_loss TEXT NOT NULL,
    take_profit TEXT NOT NULL,
    lot_size TEXT NOT NULL,
    result TEXT NOT NULL CHECK(result IN ('win', 'loss')),
    session TEXT NOT NULL CHECK(session IN ('Asia', 'London', 'New York')),
    notes TEXT NOT NULL DEFAULT '',
    date TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_trades_user_date ON trades(user_id, date DESC);
`);

function mapTrade(row: Record<string, unknown>): TradeRecord {
  return {
    id: String(row.id),
    userId: String(row.user_id),
    pair: String(row.pair),
    entryPrice: String(row.entry_price),
    stopLoss: String(row.stop_loss),
    takeProfit: String(row.take_profit),
    lotSize: String(row.lot_size),
    result: row.result === "loss" ? "loss" : "win",
    session:
      row.session === "Asia" || row.session === "New York"
        ? row.session
        : "London",
    notes: String(row.notes ?? ""),
    date: String(row.date),
  };
}

export function createTrade(input: NewTradeInput): TradeRecord {
  const trade: TradeRecord = {
    id: Date.now().toString() + Math.random().toString(36).slice(2, 11),
    userId: input.userId,
    pair: input.pair.trim().toUpperCase(),
    entryPrice: input.entryPrice.trim(),
    stopLoss: input.stopLoss.trim(),
    takeProfit: input.takeProfit.trim(),
    lotSize: input.lotSize.trim(),
    result: input.result,
    session: input.session,
    notes: input.notes?.trim() ?? "",
    date: new Date().toISOString(),
  };

  db.prepare(
    `INSERT INTO trades (
      id,
      user_id,
      pair,
      entry_price,
      stop_loss,
      take_profit,
      lot_size,
      result,
      session,
      notes,
      date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
  ).run(
    trade.id,
    trade.userId,
    trade.pair,
    trade.entryPrice,
    trade.stopLoss,
    trade.takeProfit,
    trade.lotSize,
    trade.result,
    trade.session,
    trade.notes,
    trade.date,
  );

  return trade;
}

export function listTrades(userId: string): TradeRecord[] {
  const rows = db
    .prepare("SELECT * FROM trades WHERE user_id = ? ORDER BY date DESC")
    .all(userId) as Record<string, unknown>[];
  return rows.map(mapTrade);
}

export function deleteTrade(userId: string, tradeId: string): boolean {
  const result = db
    .prepare("DELETE FROM trades WHERE user_id = ? AND id = ?")
    .run(userId, tradeId);
  return result.changes > 0;
}

export function getAnalytics(userId: string) {
  const trades = listTrades(userId);
  const total = trades.length;
  const wins = trades.filter((trade) => trade.result === "win").length;
  const losses = trades.filter((trade) => trade.result === "loss").length;
  const winRate = total > 0 ? Math.round((wins / total) * 100) : 0;

  const sessionStats = ["Asia", "London", "New York"].map((session) => {
    const sessionTrades = trades.filter((trade) => trade.session === session);
    const sessionWins = sessionTrades.filter(
      (trade) => trade.result === "win",
    ).length;
    return {
      session,
      total: sessionTrades.length,
      winRate:
        sessionTrades.length > 0
          ? Math.round((sessionWins / sessionTrades.length) * 100)
          : 0,
    };
  });

  const pairMap = new Map<string, { wins: number; total: number }>();
  for (const trade of trades) {
    const current = pairMap.get(trade.pair) ?? { wins: 0, total: 0 };
    current.total += 1;
    if (trade.result === "win") current.wins += 1;
    pairMap.set(trade.pair, current);
  }

  const pairStats = Array.from(pairMap.entries())
    .map(([pair, stats]) => ({
      pair,
      wins: stats.wins,
      total: stats.total,
      winRate: Math.round((stats.wins / stats.total) * 100),
    }))
    .sort((a, b) => b.total - a.total);

  return {
    trades,
    stats: { total, wins, losses, winRate },
    sessionStats,
    pairStats,
  };
}
