export interface User {
  id: string;
  name: string;
  email: string;
  plan: "free" | "premium";
  createdAt: string;
}

export interface Trade {
  id: string;
  pair: string;
  entryPrice: string;
  stopLoss: string;
  takeProfit: string;
  lotSize: string;
  result: "win" | "loss";
  session: "Asia" | "London" | "New York";
  notes: string;
  date: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  level: "Beginner" | "Intermediate" | "Advanced";
  content: string;
}

export interface PaymentProof {
  id: string;
  userId: string;
  imageUri: string;
  status: "pending" | "approved" | "rejected";
  submittedAt: string;
}

export interface CoachAdvice {
  analysis: string;
  mistakes: string[];
  rule: string;
}
