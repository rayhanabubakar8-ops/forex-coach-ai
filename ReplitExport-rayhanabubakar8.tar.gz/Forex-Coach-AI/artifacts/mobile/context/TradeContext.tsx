import React, { createContext, useContext, useEffect, useState } from "react";

import { useAuth } from "@/context/AuthContext";
import {
  addTradeToServer,
  deleteTradeFromServer,
  getTradesFromServer,
} from "@/lib/api";
import type { Trade } from "@/types";

interface TradeContextType {
  trades: Trade[];
  isLoading: boolean;
  error: string | null;
  refreshTrades: () => Promise<void>;
  addTrade: (trade: Omit<Trade, "id" | "date">) => Promise<void>;
  deleteTrade: (id: string) => Promise<void>;
  getStats: () => {
    total: number;
    wins: number;
    losses: number;
    winRate: number;
  };
}

const TradeContext = createContext<TradeContextType>({
  trades: [],
  isLoading: true,
  error: null,
  refreshTrades: async () => {},
  addTrade: async () => {},
  deleteTrade: async () => {},
  getStats: () => ({ total: 0, wins: 0, losses: 0, winRate: 0 }),
});

export function TradeProvider({ children }: { children: React.ReactNode }) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      refreshTrades();
    } else {
      setTrades([]);
      setError(null);
      setIsLoading(false);
    }
  }, [user?.id]);

  async function refreshTrades() {
    if (!user) return;
    setIsLoading(true);
    setError(null);
    try {
      const serverTrades = await getTradesFromServer(user.id);
      setTrades(serverTrades);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load trades.");
    } finally {
      setIsLoading(false);
    }
  }

  async function addTrade(trade: Omit<Trade, "id" | "date">) {
    if (!user) throw new Error("You must be logged in to add trades.");
    setError(null);
    const saved = await addTradeToServer({ ...trade, userId: user.id });
    setTrades((current) => [saved, ...current]);
  }

  async function deleteTrade(id: string) {
    if (!user) return;
    setError(null);
    const deleted = await deleteTradeFromServer(user.id, id);
    if (deleted) {
      setTrades((current) => current.filter((trade) => trade.id !== id));
    }
  }

  function getStats() {
    const total = trades.length;
    const wins = trades.filter((trade) => trade.result === "win").length;
    const losses = trades.filter((trade) => trade.result === "loss").length;
    const winRate = total > 0 ? Math.round((wins / total) * 100) : 0;
    return { total, wins, losses, winRate };
  }

  return (
    <TradeContext.Provider
      value={{
        trades,
        isLoading,
        error,
        refreshTrades,
        addTrade,
        deleteTrade,
        getStats,
      }}
    >
      {children}
    </TradeContext.Provider>
  );
}

export function useTrades() {
  return useContext(TradeContext);
}
