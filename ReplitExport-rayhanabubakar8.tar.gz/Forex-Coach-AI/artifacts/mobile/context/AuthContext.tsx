import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

import { getUserFromServer, syncUserToServer, upgradeUserOnServer } from "@/lib/api";
import type { User } from "@/types";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  updatePlan: (plan: "free" | "premium") => Promise<void>;
  refreshUserPlan: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isLoading: true,
  login: async () => false,
  signup: async () => false,
  logout: async () => {},
  updatePlan: async () => {},
  refreshUserPlan: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUser();
  }, []);

  async function persistUser(nextUser: User) {
    setUser(nextUser);
    await AsyncStorage.setItem("trademind_user", JSON.stringify(nextUser));
  }

  async function loadUser() {
    try {
      const stored = await AsyncStorage.getItem("trademind_user");
      if (stored) {
        const localUser = JSON.parse(stored) as User;
        setUser(localUser);
        try {
          const serverUser = await getUserFromServer(localUser.id);
          await persistUser({ ...localUser, ...serverUser });
        } catch {
          await syncUserToServer(localUser);
        }
      }
    } catch {
    } finally {
      setIsLoading(false);
    }
  }

  async function login(email: string, _password: string): Promise<boolean> {
    try {
      const stored = await AsyncStorage.getItem("trademind_users");
      const users: (User & { password: string })[] = stored
        ? JSON.parse(stored)
        : [];
      const found = users.find((u) => u.email === email);
      if (found) {
        const { password: _, ...userData } = found;
        let nextUser = userData;
        try {
          nextUser = await getUserFromServer(userData.id);
        } catch {
          nextUser = await syncUserToServer(userData);
        }
        await persistUser(nextUser);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  async function signup(
    name: string,
    email: string,
    password: string,
  ): Promise<boolean> {
    try {
      const stored = await AsyncStorage.getItem("trademind_users");
      const users: (User & { password: string })[] = stored
        ? JSON.parse(stored)
        : [];
      if (users.find((u) => u.email === email)) return false;
      const newUser: User & { password: string } = {
        id:
          Date.now().toString() + Math.random().toString(36).substr(2, 9),
        name,
        email,
        password,
        plan: "free",
        createdAt: new Date().toISOString(),
      };
      users.push(newUser);
      await AsyncStorage.setItem("trademind_users", JSON.stringify(users));
      const { password: _, ...userData } = newUser;
      const serverUser = await syncUserToServer(userData);
      await persistUser(serverUser);
      return true;
    } catch {
      return false;
    }
  }

  async function logout() {
    setUser(null);
    await AsyncStorage.removeItem("trademind_user");
  }

  async function updatePlan(plan: "free" | "premium") {
    if (!user) return;
    const updated = plan === "premium" ? await upgradeUserOnServer(user.id) : { ...user, plan };
    await persistUser(updated);
    const stored = await AsyncStorage.getItem("trademind_users");
    const users: (User & { password: string })[] = stored
      ? JSON.parse(stored)
      : [];
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      users[idx] = { ...users[idx], ...updated };
      await AsyncStorage.setItem("trademind_users", JSON.stringify(users));
    }
  }

  async function refreshUserPlan() {
    if (!user) return;
    try {
      const serverUser = await getUserFromServer(user.id);
      await persistUser({ ...user, ...serverUser });
    } catch {
    }
  }

  return (
    <AuthContext.Provider
      value={{ user, isLoading, login, signup, logout, updatePlan, refreshUserPlan }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
