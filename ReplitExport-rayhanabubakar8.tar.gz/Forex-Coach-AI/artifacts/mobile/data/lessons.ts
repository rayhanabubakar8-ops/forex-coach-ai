import type { Lesson } from "@/types";

export const lessons: Lesson[] = [
  {
    id: "1",
    title: "Market Structure",
    description: "Learn how price moves in trends, ranges, and reversals",
    level: "Beginner",
    content:
      "Market structure is the foundation of technical analysis. Price moves in three main ways:\n\n1. UPTREND: Higher highs and higher lows. Buyers are in control.\n\n2. DOWNTREND: Lower highs and lower lows. Sellers are in control.\n\n3. RANGE: Price bounces between support and resistance.\n\nKey concept: Break of Structure (BOS) happens when price breaks the previous high (in an uptrend) or low (in a downtrend). This confirms trend continuation.\n\nChange of Character (ChoCh) happens when the trend shifts direction. For example, in an uptrend, when price makes a lower low instead of a higher low.\n\nAlways identify the current market structure before taking a trade. Trading with the trend increases your probability of success.",
  },
  {
    id: "2",
    title: "Support & Resistance",
    description: "Identify key price levels where markets react",
    level: "Beginner",
    content:
      "Support and resistance are price levels where buying or selling pressure is strong enough to stop price movement.\n\nSUPPORT: A price level where buyers step in and prevent further decline. Think of it as a floor.\n\nRESISTANCE: A price level where sellers step in and prevent further advance. Think of it as a ceiling.\n\nKey rules:\n- The more times a level is tested, the stronger it becomes\n- When support breaks, it often becomes resistance (and vice versa)\n- Round numbers (1.2000, 1.3000) often act as psychological S/R\n- Use higher timeframes to identify major levels\n\nPro tip: Don't draw too many levels. Focus on the most obvious ones that institutional traders would watch. If a level is not clear, it's probably not important.",
  },
  {
    id: "3",
    title: "Candlestick Patterns",
    description: "Read price action through candlestick formations",
    level: "Beginner",
    content:
      "Candlesticks tell you the story of buyers vs sellers in each time period.\n\nBULLISH PATTERNS:\n- Engulfing: A large green candle completely covers the previous red candle. Strong reversal signal.\n- Hammer: Small body at top with long lower wick. Buyers rejected lower prices.\n- Morning Star: Three candle pattern showing reversal from bearish to bullish.\n\nBEARISH PATTERNS:\n- Engulfing: A large red candle completely covers the previous green candle.\n- Shooting Star: Small body at bottom with long upper wick. Sellers rejected higher prices.\n- Evening Star: Three candle pattern showing reversal from bullish to bearish.\n\nIMPORTANT: Candlestick patterns are more reliable at key support/resistance levels. A hammer at support is much more significant than a hammer in the middle of nowhere.\n\nAlways confirm with context. Never trade a pattern in isolation.",
  },
  {
    id: "4",
    title: "Risk Management",
    description: "Protect your capital with proper position sizing",
    level: "Intermediate",
    content:
      "Risk management is what separates profitable traders from gamblers.\n\nTHE 1% RULE:\nNever risk more than 1-2% of your account on a single trade. If you have $10,000, your maximum loss per trade should be $100-$200.\n\nPOSITION SIZING FORMULA:\nLot Size = (Account Balance x Risk %) / (Stop Loss in Pips x Pip Value)\n\nRISK-TO-REWARD RATIO (RR):\nAlways aim for at least 1:2 RR. This means your potential profit should be at least 2x your potential loss.\n\nWith 1:2 RR, you only need to win 34% of trades to be profitable!\n\nKEY RULES:\n- Always use a stop loss\n- Never move your stop loss further from entry\n- Never risk money you can't afford to lose\n- Don't revenge trade after a loss\n- Keep a trading journal to track your risk habits",
  },
  {
    id: "5",
    title: "Trading Sessions",
    description: "Trade at the right time for maximum opportunity",
    level: "Intermediate",
    content:
      "The forex market operates 24/5 across three major sessions:\n\nASIA SESSION (Tokyo): 00:00 - 09:00 GMT\n- Lower volatility, good for range trading\n- Best pairs: USD/JPY, AUD/USD, NZD/USD\n- Smaller moves, tighter ranges\n\nLONDON SESSION: 07:00 - 16:00 GMT\n- Highest volume and volatility\n- Best for breakout trades\n- Major pairs move significantly\n- London open often sets the daily direction\n\nNEW YORK SESSION: 12:00 - 21:00 GMT\n- Second most active session\n- London-NY overlap (12:00-16:00) is the most volatile period\n- Major news releases from US\n- Good for trend continuation\n\nPRO TIPS:\n- Focus on 1-2 sessions maximum\n- Track which session your wins come from\n- Avoid trading during low-volume periods\n- News events can override normal session behavior",
  },
  {
    id: "6",
    title: "Trading Journal Best Practices",
    description: "Track your trades to improve consistently",
    level: "Intermediate",
    content:
      "A trading journal is your most powerful improvement tool.\n\nWHAT TO RECORD:\n- Entry and exit prices\n- Stop loss and take profit levels\n- Lot size and risk percentage\n- Trading session\n- Setup type / strategy used\n- Screenshot of the chart\n- Your emotional state\n- Outcome (win/loss/breakeven)\n\nWEEKLY REVIEW PROCESS:\n1. Count wins and losses\n2. Calculate win rate\n3. Average risk-to-reward ratio\n4. Identify your best performing pairs\n5. Identify your best performing sessions\n6. Note recurring mistakes\n\nCOMMON PATTERNS TO WATCH:\n- Overtrading (too many trades per day)\n- Revenge trading after losses\n- Moving stop losses\n- Trading outside your best session\n\nConsistency in journaling leads to consistency in trading.",
  },
  {
    id: "7",
    title: "Liquidity",
    description: "Understand where smart money hunts for orders",
    level: "Advanced",
    content:
      "Liquidity refers to pending orders sitting in the market, typically above swing highs and below swing lows.\n\nTYPES OF LIQUIDITY:\n- Buy-side liquidity (BSL): Stop losses from short sellers sitting above swing highs\n- Sell-side liquidity (SSL): Stop losses from buyers sitting below swing lows\n\nLIQUIDITY SWEEPS:\nInstitutional traders (smart money) need liquidity to fill their large orders. They push price into areas where stops are clustered, grab the liquidity, then reverse.\n\nHOW TO TRADE IT:\n1. Identify obvious swing highs/lows where retail traders place stops\n2. Wait for price to sweep past these levels\n3. Look for a reversal signal after the sweep\n4. Enter in the direction of the reversal\n\nKEY INSIGHT: If equal highs or equal lows form, liquidity is building there. Smart money will likely target it.\n\nThe market is designed to hunt stops. Once you understand this, you can position yourself alongside smart money instead of being their exit liquidity.",
  },
  {
    id: "8",
    title: "Order Blocks",
    description: "Find institutional entry zones for high-probability trades",
    level: "Advanced",
    content:
      "Order blocks are specific candles where institutional traders placed large orders.\n\nBULLISH ORDER BLOCK:\nThe last bearish candle before a strong bullish move. This is where institutions accumulated buy orders before pushing price up.\n\nBEARISH ORDER BLOCK:\nThe last bullish candle before a strong bearish move. This is where institutions distributed sell orders before pushing price down.\n\nHOW TO IDENTIFY:\n1. Find a strong impulsive move that broke structure\n2. Go back to the origin of the move\n3. The last opposite-colored candle is your order block\n4. Mark the high and low of that candle as your zone\n\nHOW TO TRADE:\n1. Wait for price to return to the order block zone\n2. Look for a reaction (rejection candle, engulfing)\n3. Enter with stop loss below/above the order block\n4. Target the next liquidity level\n\nORDER BLOCK RULES:\n- Must cause a break of structure\n- Higher timeframe order blocks are stronger\n- Unmitigated (untested) order blocks are more powerful\n- First touch of an order block has highest probability",
  },
  {
    id: "9",
    title: "Fair Value Gaps",
    description: "Trade imbalances left by aggressive price movements",
    level: "Advanced",
    content:
      "A Fair Value Gap (FVG) is an imbalance in price created when a large candle leaves a gap between the candles before and after it.\n\nHOW TO IDENTIFY:\nLook at three consecutive candles:\n- Candle 1: Note the high (for bullish) or low (for bearish)\n- Candle 2: The large impulse candle\n- Candle 3: Note the low (for bullish) or high (for bearish)\n\nIf there's a gap between Candle 1's high and Candle 3's low (bullish FVG), or Candle 1's low and Candle 3's high (bearish FVG), you have an FVG.\n\nWHY THEY WORK:\nFVGs represent areas where price moved too fast, leaving unfilled orders. Price tends to return to fill these gaps before continuing.\n\nTRADING FVGs:\n1. Identify the FVG on a higher timeframe\n2. Wait for price to retrace into the gap\n3. Enter at the 50% level of the FVG for optimal entry\n4. Stop loss beyond the FVG boundary\n5. Target the next swing point or liquidity level\n\nNot all FVGs get filled. FVGs in strong trends may remain open. Focus on FVGs that align with the overall market structure and order flow.",
  },
];
