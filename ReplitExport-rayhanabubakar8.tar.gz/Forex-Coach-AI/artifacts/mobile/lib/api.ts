import { Platform } from "react-native";
import type { CoachAdvice, Trade, User } from "@/types";

export interface AnalyticsResponse {
  trades: Trade[];
  stats: {
    total: number;
    wins: number;
    losses: number;
    winRate: number;
  };
  sessionStats: {
    session: string;
    total: number;
    winRate: number;
  }[];
  pairStats: {
    pair: string;
    wins: number;
    total: number;
    winRate: number;
  }[];
  coach: CoachAdvice & { source?: "openai" | "rules" };
}

export interface TradingAccount {
  id: number;
  name: string;
  type: "personal" | "prop";
  balance: number;
  dailyLossLimit: number;
  maxDrawdown: number;
  profitTarget: number;
}

export interface AccountTrade {
  id: number;
  accountId: number;
  pair: string;
  pnl: number;
  date: string;
}

export interface AccountAnalyticsResponse {
  account: TradingAccount;
  balance: number;
  equity: number;
  total_pnl: number;
  daily_pnl: number;
  drawdown: number;
  status: "SAFE" | "DAILY LOSS LIMIT HIT" | "MAX DRAWDOWN HIT" | "TARGET REACHED";
}

export interface PaymentInstructions {
  network: "TRC20";
  address: string;
}

export interface PaymentSubmission {
  id: number;
  userId: string;
  txid: string;
  amount: number;
  network: string;
  address: string;
  status: "pending" | "approved" | "rejected";
  submittedAt: string;
  verifiedAt: string | null;
}

const explicitApiBase = process.env.EXPO_PUBLIC_API_BASE_URL;
const domain = process.env.EXPO_PUBLIC_DOMAIN;

function getApiBase(): string {
  if (explicitApiBase) {
    return explicitApiBase.replace(/\/$/, "");
  }
  if (domain) {
    return `https://${domain}/api`;
  }
  if (Platform.OS === "web" && typeof window !== "undefined") {
    return `${window.location.origin}/api`;
  }
  throw new Error("Backend URL is not configured for this app.");
}

const API_BASE = getApiBase();

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) {
    const message =
      data && typeof data.error === "string"
        ? data.error
        : "The server could not complete the request.";
    throw new Error(message);
  }
  return data as T;
}

export async function checkBackendHealth(): Promise<boolean> {
  const response = await fetch(`${API_BASE}/health`, { method: "GET" });
  const text = await response.text();
  return response.ok && text.trim() === "OK";
}

export async function syncUserToServer(user: User): Promise<User> {
  const data = await request<{ user: User }>("/sync_user", {
    method: "POST",
    body: JSON.stringify(user),
  });
  return data.user;
}

export async function getUserFromServer(userId: string): Promise<User> {
  const data = await request<{ user: User }>(
    `/user/${encodeURIComponent(userId)}`,
  );
  return data.user;
}

export async function getPaymentInstructions(): Promise<PaymentInstructions> {
  return request<PaymentInstructions>("/payment_instructions");
}

export async function submitPaymentRequest(input: {
  userId: string;
  txid: string;
  amount: number;
}): Promise<PaymentSubmission> {
  const data = await request<{
    message: string;
    payment: PaymentSubmission;
  }>("/submit_payment", {
    method: "POST",
    body: JSON.stringify(input),
  });
  return data.payment;
}

export async function upgradeUserOnServer(userId: string): Promise<User> {
  const data = await request<{ message: string; user: User }>("/upgrade_user", {
    method: "POST",
    body: JSON.stringify({ userId }),
  });
  return data.user;
}

export async function addTradeToServer(
  trade: Omit<Trade, "id" | "date"> & { userId: string },
): Promise<Trade> {
  const data = await request<{ trade: Trade }>("/add_trade", {
    method: "POST",
    body: JSON.stringify(trade),
  });
  return data.trade;
}

export async function getTradesFromServer(userId: string): Promise<Trade[]> {
  const data = await request<{ trades: Trade[] }>(
    `/get_trades?userId=${encodeURIComponent(userId)}`,
  );
  return data.trades;
}

export async function deleteTradeFromServer(
  userId: string,
  tradeId: string,
): Promise<boolean> {
  const data = await request<{ deleted: boolean }>(
    `/delete_trade/${encodeURIComponent(tradeId)}?userId=${encodeURIComponent(userId)}`,
    { method: "DELETE" },
  );
  return data.deleted;
}

export async function getAnalyticsFromServer(
  userId: string,
): Promise<AnalyticsResponse> {
  return request<AnalyticsResponse>(
    `/analytics?userId=${encodeURIComponent(userId)}`,
  );
}

export async function createTradingAccount(input: {
  name: string;
  type: "personal" | "prop";
  balance: number;
  daily_loss_limit: number;
  max_drawdown: number;
  profit_target: number;
}): Promise<TradingAccount> {
  const data = await request<{
    message: string;
    account: TradingAccount;
  }>("/create_account", {
    method: "POST",
    body: JSON.stringify(input),
  });
  return data.account;
}

export async function getTradingAccounts(): Promise<TradingAccount[]> {
  const data = await request<{ accounts: TradingAccount[] }>("/accounts");
  return data.accounts;
}

export async function addAccountTrade(input: {
  account_id: number;
  pair: string;
  pnl: number;
}): Promise<AccountTrade> {
  const data = await request<{
    message: string;
    trade: AccountTrade;
  }>("/add_account_trade", {
    method: "POST",
    body: JSON.stringify(input),
  });
  return data.trade;
}

export async function getAccountTrades(accountId: number): Promise<AccountTrade[]> {
  const data = await request<{ trades: AccountTrade[] }>(
    `/account_trades/${encodeURIComponent(String(accountId))}`,
  );
  return data.trades;
}

export async function getAccountAnalytics(
  accountId: number,
): Promise<AccountAnalyticsResponse> {
  return request<AccountAnalyticsResponse>(
    `/analytics/${encodeURIComponent(String(accountId))}`,
  );
}
