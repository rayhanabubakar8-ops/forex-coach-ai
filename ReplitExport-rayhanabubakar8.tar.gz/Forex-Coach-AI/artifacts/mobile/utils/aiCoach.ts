import type { CoachAdvice, Trade } from "@/types";

export function analyzePerformance(trades: Trade[]): CoachAdvice {
  if (trades.length === 0) {
    return {
      analysis:
        "You haven't logged any trades yet. Start journaling your trades to receive personalized coaching. Every professional trader keeps a journal.",
      mistakes: [],
      rule: "Log at least 5 trades before your first analysis. Consistency starts with tracking.",
    };
  }

  const total = trades.length;
  const wins = trades.filter((t) => t.result === "win").length;
  const losses = trades.filter((t) => t.result === "loss").length;
  const winRate = Math.round((wins / total) * 100);

  const mistakes: string[] = [];
  let analysis = "";
  let rule = "";

  const rrValues = trades.map((t) => {
    const entry = parseFloat(t.entryPrice);
    const sl = parseFloat(t.stopLoss);
    const tp = parseFloat(t.takeProfit);
    if (!entry || !sl || !tp) return 0;
    const risk = Math.abs(entry - sl);
    const reward = Math.abs(tp - entry);
    return risk > 0 ? reward / risk : 0;
  });
  const avgRR =
    rrValues.length > 0
      ? rrValues.reduce((a, b) => a + b, 0) / rrValues.length
      : 0;

  const today = new Date().toDateString();
  const tradesToday = trades.filter(
    (t) => new Date(t.date).toDateString() === today,
  ).length;

  const sessionCounts: Record<string, number> = {};
  trades.forEach((t) => {
    sessionCounts[t.session] = (sessionCounts[t.session] || 0) + 1;
  });

  const pairCounts: Record<string, number> = {};
  trades.forEach((t) => {
    pairCounts[t.pair] = (pairCounts[t.pair] || 0) + 1;
  });

  const pairWinRates: Record<string, { wins: number; total: number }> = {};
  trades.forEach((t) => {
    if (!pairWinRates[t.pair]) pairWinRates[t.pair] = { wins: 0, total: 0 };
    pairWinRates[t.pair].total++;
    if (t.result === "win") pairWinRates[t.pair].wins++;
  });

  if (tradesToday > 3) {
    mistakes.push(
      `Overtrading detected: ${tradesToday} trades today. Quality over quantity.`,
    );
  }

  if (avgRR < 1.5) {
    mistakes.push(
      `Low risk-to-reward ratio (${avgRR.toFixed(1)}:1). Aim for at least 2:1 RR on every trade.`,
    );
  }

  if (winRate < 40 && total >= 5) {
    mistakes.push(
      `Win rate is ${winRate}%. Review your entry criteria and only take A+ setups.`,
    );
  }

  const recentTrades = trades.slice(0, 5);
  const recentLosses = recentTrades.filter((t) => t.result === "loss").length;
  if (recentLosses >= 4) {
    mistakes.push(
      "Losing streak detected. Step away from the charts. Revenge trading will destroy your account.",
    );
  }

  const noNotes = trades.filter((t) => !t.notes.trim()).length;
  if (noNotes > total * 0.5) {
    mistakes.push(
      "Most trades have no notes. Document your reasoning for every trade to learn from mistakes.",
    );
  }

  if (winRate >= 60 && avgRR >= 2) {
    analysis = `Strong performance. ${winRate}% win rate with ${avgRR.toFixed(1)}:1 average RR. You're on the right track. Stay disciplined and don't get overconfident. The market humbles everyone eventually.`;
    rule = "Don't change what's working. Stick to your current strategy for the next 20 trades.";
  } else if (winRate >= 50) {
    analysis = `Decent results with ${winRate}% win rate, but your RR of ${avgRR.toFixed(1)}:1 needs improvement. You're winning trades but not maximizing profits. Let winners run longer.`;
    rule = "For the next 10 trades, set your take profit at minimum 2x your stop loss. No exceptions.";
  } else if (winRate >= 35) {
    analysis = `Your ${winRate}% win rate is below average. With ${total} trades logged, there's a clear pattern of taking low-quality setups. You need to be more selective.`;
    rule = "Reduce to maximum 2 trades per day. Only take setups that score 8/10 or higher on your checklist.";
  } else {
    analysis = `${winRate}% win rate is concerning. You're losing more than you're winning with ${avgRR.toFixed(1)}:1 RR. Something fundamental needs to change in your approach.`;
    rule = "Go back to demo trading for one week. Focus only on market structure and take zero live trades until you achieve 50%+ win rate on demo.";
  }

  if (mistakes.length === 0) {
    mistakes.push(
      "No major issues detected. Keep maintaining your discipline and stick to your trading plan.",
    );
  }

  return { analysis, mistakes, rule };
}
