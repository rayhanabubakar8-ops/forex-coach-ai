import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useColors } from "@/hooks/useColors";

interface LessonCardProps {
  title: string;
  description: string;
  level: string;
  locked?: boolean;
  onPress: () => void;
}

const levelColors: Record<string, string> = {
  Beginner: "#00E676",
  Intermediate: "#FFD700",
  Advanced: "#FF5252",
};

export function LessonCard({
  title,
  description,
  level,
  locked,
  onPress,
}: LessonCardProps) {
  const colors = useColors();
  const levelColor = levelColors[level] ?? colors.primary;

  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.card, borderRadius: 12, opacity: locked ? 0.5 : 1 }]}
      onPress={onPress}
      activeOpacity={0.7}
      disabled={locked}
    >
      <View style={styles.content}>
        <View style={[styles.levelDot, { backgroundColor: levelColor }]} />
        <View style={styles.textWrap}>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {title}
          </Text>
          <Text
            style={[styles.description, { color: colors.mutedForeground }]}
            numberOfLines={2}
          >
            {description}
          </Text>
        </View>
        {locked ? (
          <Feather name="lock" size={18} color={colors.mutedForeground} />
        ) : (
          <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
    marginBottom: 10,
  },
  content: {
    flexDirection: "row",
    alignItems: "center",
  },
  levelDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 12,
  },
  textWrap: {
    flex: 1,
  },
  title: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 2,
  },
  description: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
  },
});
