import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  Alert,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { useColors } from "@/hooks/useColors";
import type { Trade } from "@/types";

interface TradeCardProps {
  trade: Trade;
  onDelete: (id: string) => void;
}

export function TradeCard({ trade, onDelete }: TradeCardProps) {
  const colors = useColors();
  const isWin = trade.result === "win";
  const resultColor = isWin ? colors.success : colors.loss;
  const rr = calculateRR(trade);

  function calculateRR(t: Trade) {
    const entry = parseFloat(t.entryPrice);
    const sl = parseFloat(t.stopLoss);
    const tp = parseFloat(t.takeProfit);
    if (!entry || !sl || !tp) return "N/A";
    const risk = Math.abs(entry - sl);
    const reward = Math.abs(tp - entry);
    if (risk === 0) return "N/A";
    return (reward / risk).toFixed(1);
  }

  function handleDelete() {
    Alert.alert("Delete Trade", "Are you sure you want to delete this trade?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: () => onDelete(trade.id),
      },
    ]);
  }

  const dateStr = new Date(trade.date).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  return (
    <View
      style={[styles.card, { backgroundColor: colors.card, borderRadius: 12 }]}
    >
      <View style={styles.header}>
        <View style={styles.pairRow}>
          <Text style={[styles.pair, { color: colors.foreground }]}>
            {trade.pair}
          </Text>
          <View
            style={[
              styles.resultBadge,
              { backgroundColor: resultColor + "20" },
            ]}
          >
            <Text style={[styles.resultText, { color: resultColor }]}>
              {trade.result.toUpperCase()}
            </Text>
          </View>
        </View>
        <TouchableOpacity onPress={handleDelete} hitSlop={8}>
          <Feather name="trash-2" size={16} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            Entry
          </Text>
          <Text style={[styles.detailValue, { color: colors.foreground }]}>
            {trade.entryPrice}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            SL
          </Text>
          <Text style={[styles.detailValue, { color: colors.loss }]}>
            {trade.stopLoss}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            TP
          </Text>
          <Text style={[styles.detailValue, { color: colors.success }]}>
            {trade.takeProfit}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            RR
          </Text>
          <Text style={[styles.detailValue, { color: colors.accent }]}>
            {rr}
          </Text>
        </View>
      </View>

      <View style={[styles.footer, { borderTopColor: colors.border }]}>
        <View style={styles.footerItem}>
          <Feather name="layers" size={12} color={colors.mutedForeground} />
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
            {trade.lotSize} lots
          </Text>
        </View>
        <View style={styles.footerItem}>
          <Feather name="clock" size={12} color={colors.mutedForeground} />
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
            {trade.session}
          </Text>
        </View>
        <View style={styles.footerItem}>
          <Feather name="calendar" size={12} color={colors.mutedForeground} />
          <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
            {dateStr}
          </Text>
        </View>
      </View>

      {trade.notes ? (
        <Text
          style={[styles.notes, { color: colors.mutedForeground }]}
          numberOfLines={2}
        >
          {trade.notes}
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: 16,
    marginBottom: 12,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  pairRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  pair: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  resultBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  resultText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  details: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  detailRow: {
    alignItems: "center",
  },
  label: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  footer: {
    flexDirection: "row",
    gap: 16,
    paddingTop: 12,
    borderTopWidth: 1,
  },
  footerItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  footerText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  notes: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 8,
    fontStyle: "italic",
  },
});
