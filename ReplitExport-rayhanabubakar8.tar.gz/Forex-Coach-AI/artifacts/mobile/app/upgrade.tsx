import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { getPaymentInstructions, submitPaymentRequest } from "@/lib/api";

const features = [
  "Prop firm mode with drawdown tracking",
  "Advanced analytics and pair performance",
  "Unlimited AI coach reviews",
  "CSV trade upload",
  "Trading University full access",
];

export default function UpgradeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, refreshUserPlan } = useAuth();
  const [txid, setTxid] = useState("");
  const [amount, setAmount] = useState("");
  const [network, setNetwork] = useState("TRC20");
  const [address, setAddress] = useState("YOUR_BYBIT_USDT_ADDRESS");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const webTop = Platform.OS === "web" ? 67 : 0;

  useEffect(() => {
    getPaymentInstructions()
      .then((instructions) => {
        setNetwork(instructions.network);
        setAddress(instructions.address);
      })
      .catch(() => {});
  }, []);

  async function handleSubmit() {
    if (!user) {
      Alert.alert("Login Required", "Please sign in before upgrading.");
      return;
    }
    if (!txid.trim() || !amount.trim()) {
      Alert.alert("Missing Details", "Please enter your TXID and amount.");
      return;
    }
    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      Alert.alert("Invalid Amount", "Please enter a valid USDT amount.");
      return;
    }

    setLoading(true);
    try {
      await submitPaymentRequest({ userId: user.id, txid, amount: numericAmount });
      if (Platform.OS !== "web") {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      setSubmitted(true);
    } catch (error) {
      Alert.alert(
        "Submission Failed",
        error instanceof Error ? error.message : "Unable to submit payment.",
      );
    } finally {
      setLoading(false);
    }
  }

  if (submitted) {
    return (
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.background,
            justifyContent: "center",
            alignItems: "center",
            paddingHorizontal: 16,
          },
        ]}
      >
        <View style={[styles.successIcon, { backgroundColor: colors.success + "20" }]}>
          <Feather name="clock" size={48} color={colors.success} />
        </View>
        <Text style={[styles.successTitle, { color: colors.foreground }]}>Payment Submitted</Text>
        <Text style={[styles.successText, { color: colors.mutedForeground }]}>
          Your payment request is pending manual verification. Once approved, your plan will be upgraded to Premium automatically.
        </Text>
        <TouchableOpacity
          style={[styles.successBtn, { backgroundColor: colors.primary, borderRadius: 12 }]}
          onPress={async () => {
            await refreshUserPlan();
            router.back();
          }}
          activeOpacity={0.7}
        >
          <Text style={[styles.successBtnText, { color: colors.primaryForeground }]}>Back to App</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 40,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <TouchableOpacity style={styles.backBtn} onPress={() => router.back()} hitSlop={8}>
        <Feather name="arrow-left" size={24} color={colors.foreground} />
      </TouchableOpacity>

      <View style={styles.headerSection}>
        <View style={[styles.starWrap, { backgroundColor: colors.accent + "20" }]}> 
          <Feather name="star" size={32} color={colors.accent} />
        </View>
        <Text style={[styles.title, { color: colors.foreground }]}>Upgrade to Premium</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Unlock prop firm tools, unlimited AI coaching, CSV upload, and full education access.</Text>
      </View>

      <View style={[styles.featuresCard, { backgroundColor: colors.card, borderRadius: 12 }]}> 
        {features.map((feature) => (
          <View key={feature} style={styles.featureRow}>
            <Feather name="check" size={18} color={colors.success} />
            <Text style={[styles.featureText, { color: colors.foreground }]}>{feature}</Text>
          </View>
        ))}
      </View>

      <View style={[styles.paymentSection, { backgroundColor: colors.card, borderRadius: 12 }]}> 
        <Text style={[styles.paymentTitle, { color: colors.foreground }]}>USDT Payment Instructions</Text>
        <Text style={[styles.paymentText, { color: colors.mutedForeground }]}>Send USDT from Bybit or any wallet using the exact network below. After payment, submit your TXID for manual verification.</Text>
        <View style={[styles.accountBox, { backgroundColor: colors.secondary, borderRadius: 8 }]}> 
          <Text style={[styles.accountLabel, { color: colors.mutedForeground }]}>Network</Text>
          <Text style={[styles.accountValue, { color: colors.foreground }]}>{network}</Text>
          <Text style={[styles.accountLabel, { color: colors.mutedForeground, marginTop: 10 }]}>Address</Text>
          <Text selectable style={[styles.addressValue, { color: colors.foreground }]}>{address}</Text>
        </View>
      </View>

      <Text style={[styles.proofLabel, { color: colors.foreground }]}>Submit Payment Details</Text>

      <TextInput
        style={[styles.input, { backgroundColor: colors.card, color: colors.foreground, borderColor: colors.border }]}
        value={txid}
        onChangeText={setTxid}
        placeholder="Transaction ID (TXID)"
        placeholderTextColor={colors.mutedForeground}
        autoCapitalize="none"
      />
      <TextInput
        style={[styles.input, { backgroundColor: colors.card, color: colors.foreground, borderColor: colors.border }]}
        value={amount}
        onChangeText={setAmount}
        placeholder="Amount paid in USDT"
        placeholderTextColor={colors.mutedForeground}
        keyboardType="decimal-pad"
      />

      <TouchableOpacity
        style={[
          styles.submitBtn,
          {
            backgroundColor: txid.trim() && amount.trim() ? colors.accent : colors.muted,
            borderRadius: 12,
          },
        ]}
        onPress={handleSubmit}
        activeOpacity={0.7}
        disabled={!txid.trim() || !amount.trim() || loading}
      >
        <Text style={[styles.submitText, { color: txid.trim() && amount.trim() ? colors.accentForeground : colors.mutedForeground }]}> {loading ? "Submitting..." : "Submit Payment"}</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  backBtn: { marginBottom: 16 },
  headerSection: { alignItems: "center", marginBottom: 24 },
  starWrap: { width: 64, height: 64, borderRadius: 20, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  title: { fontSize: 24, fontFamily: "Inter_700Bold", marginBottom: 6 },
  subtitle: { fontSize: 15, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
  featuresCard: { padding: 16, marginBottom: 20, gap: 14 },
  featureRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  featureText: { fontSize: 15, fontFamily: "Inter_500Medium", flex: 1 },
  paymentSection: { padding: 16, marginBottom: 20 },
  paymentTitle: { fontSize: 16, fontFamily: "Inter_700Bold", marginBottom: 8 },
  paymentText: { fontSize: 13, fontFamily: "Inter_400Regular", marginBottom: 12, lineHeight: 20 },
  accountBox: { padding: 12, marginBottom: 8 },
  accountLabel: { fontSize: 12, fontFamily: "Inter_600SemiBold", marginBottom: 4 },
  accountValue: { fontSize: 15, fontFamily: "Inter_700Bold", lineHeight: 22 },
  addressValue: { fontSize: 13, fontFamily: "Inter_500Medium", lineHeight: 20 },
  proofLabel: { fontSize: 16, fontFamily: "Inter_700Bold", marginBottom: 12 },
  input: { width: "100%", padding: 16, borderRadius: 12, borderWidth: 1, fontSize: 15, fontFamily: "Inter_400Regular", marginBottom: 12 },
  submitBtn: { padding: 16, alignItems: "center", marginTop: 8 },
  submitText: { fontSize: 16, fontFamily: "Inter_700Bold" },
  successIcon: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center", marginBottom: 24 },
  successTitle: { fontSize: 24, fontFamily: "Inter_700Bold", marginBottom: 12 },
  successText: { fontSize: 15, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22, marginBottom: 32 },
  successBtn: { paddingHorizontal: 32, paddingVertical: 16 },
  successBtnText: { fontSize: 16, fontFamily: "Inter_700Bold" },
});
