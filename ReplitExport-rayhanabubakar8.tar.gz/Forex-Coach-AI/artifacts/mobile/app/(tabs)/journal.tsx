import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { TradeCard } from "@/components/TradeCard";
import { useTrades } from "@/context/TradeContext";
import { useColors } from "@/hooks/useColors";

const filters = ["All", "Wins", "Losses"] as const;

export default function JournalScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { trades, deleteTrade } = useTrades();
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]>("All");
  const webTop = Platform.OS === "web" ? 67 : 0;

  const filteredTrades = trades.filter((t) => {
    if (activeFilter === "Wins") return t.result === "win";
    if (activeFilter === "Losses") return t.result === "loss";
    return true;
  });

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[styles.header, { paddingTop: insets.top + 16 + webTop }]}
      >
        <Text style={[styles.title, { color: colors.foreground }]}>
          Trade Journal
        </Text>
        <TouchableOpacity
          style={[styles.addBtn, { backgroundColor: colors.primary }]}
          onPress={() => router.push("/add-trade")}
          activeOpacity={0.7}
        >
          <Feather name="plus" size={20} color={colors.primaryForeground} />
        </TouchableOpacity>
      </View>

      <View style={styles.filterRow}>
        {filters.map((f) => (
          <TouchableOpacity
            key={f}
            style={[
              styles.filterChip,
              {
                backgroundColor:
                  activeFilter === f ? colors.primary + "20" : colors.card,
                borderRadius: 8,
              },
            ]}
            onPress={() => setActiveFilter(f)}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.filterText,
                {
                  color:
                    activeFilter === f ? colors.primary : colors.mutedForeground,
                },
              ]}
            >
              {f}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <FlatList
        data={filteredTrades}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TradeCard trade={item} onDelete={deleteTrade} />
        )}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingBottom: insets.bottom + 100,
        }}
        showsVerticalScrollIndicator={false}
        scrollEnabled={filteredTrades.length > 0}
        ListEmptyComponent={
          <View
            style={[
              styles.emptyState,
              { backgroundColor: colors.card, borderRadius: 12 },
            ]}
          >
            <Feather
              name="book-open"
              size={32}
              color={colors.mutedForeground}
            />
            <Text
              style={[styles.emptyText, { color: colors.mutedForeground }]}
            >
              No trades found. Tap + to add your first trade.
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 12,
  },
  title: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
  },
  addBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  filterRow: {
    flexDirection: "row",
    gap: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  filterChip: {
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  filterText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  emptyState: {
    padding: 32,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    marginTop: 24,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
});
