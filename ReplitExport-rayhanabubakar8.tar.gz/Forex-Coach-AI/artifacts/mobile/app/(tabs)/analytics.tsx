import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useTrades } from "@/context/TradeContext";
import { useColors } from "@/hooks/useColors";
import { getAnalyticsFromServer, type AnalyticsResponse } from "@/lib/api";

export default function AnalyticsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { trades, getStats } = useTrades();
  const [analytics, setAnalytics] = useState<AnalyticsResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const isPremium = user?.plan === "premium";
  const stats = analytics?.stats ?? getStats();
  const sessionStats = analytics?.sessionStats ?? [];
  const pairStats = analytics?.pairStats ?? [];
  const advice = analytics?.coach ?? {
    analysis:
      "Load your saved trades to receive real AI coaching from your journal data.",
    mistakes: ["No backend analysis loaded yet."],
    rule: "Log trades consistently and refresh analytics after each session.",
  };
  const webTop = Platform.OS === "web" ? 67 : 0;

  async function loadAnalytics() {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      setAnalytics(await getAnalyticsFromServer(user.id));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load analytics.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAnalytics();
  }, [user?.id, trades.length]);

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 100,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.topRow}>
        <Text style={[styles.title, { color: colors.foreground }]}>Analytics</Text>
        <TouchableOpacity
          style={[styles.refreshBtn, { backgroundColor: colors.card }]}
          onPress={loadAnalytics}
          activeOpacity={0.7}
        >
          {loading ? (
            <ActivityIndicator size="small" color={colors.primary} />
          ) : (
            <Feather name="refresh-cw" size={18} color={colors.primary} />
          )}
        </TouchableOpacity>
      </View>

      {error ? (
        <View style={[styles.errorCard, { backgroundColor: colors.destructive + "20" }]}>
          <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
        </View>
      ) : null}

      {isPremium ? (
        <View
          style={[
            styles.coachCard,
            { backgroundColor: colors.card, borderRadius: 12 },
          ]}
        >
          <View style={styles.coachHeader}>
            <View
              style={[styles.coachIcon, { backgroundColor: colors.accent + "20" }]}
            >
              <Feather name="cpu" size={20} color={colors.accent} />
            </View>
            <View style={styles.coachTitleWrap}>
              <Text style={[styles.coachTitle, { color: colors.accent }]}>AI Trading Coach</Text>
              <Text style={[styles.coachSource, { color: colors.mutedForeground }]}>Unlimited Premium coach reviews</Text>
            </View>
          </View>
          <Text style={[styles.coachText, { color: colors.foreground }]}>{advice.analysis}</Text>

          <View style={styles.mistakesSection}>
            <Text style={[styles.mistakesLabel, { color: colors.destructive }]}>Issues Detected:</Text>
            {advice.mistakes.map((mistake, index) => (
              <View key={index} style={styles.mistakeRow}>
                <Feather name="alert-triangle" size={14} color={colors.destructive} />
                <Text style={[styles.mistakeText, { color: colors.secondaryForeground }]}>{mistake}</Text>
              </View>
            ))}
          </View>

          <View
            style={[
              styles.ruleBox,
              { backgroundColor: colors.primary + "10", borderColor: colors.primary + "30" },
            ]}
          >
            <Text style={[styles.ruleLabel, { color: colors.primary }]}>Rule to Follow:</Text>
            <Text style={[styles.ruleText, { color: colors.foreground }]}>{advice.rule}</Text>
          </View>
        </View>
      ) : (
        <TouchableOpacity
          style={[styles.lockCard, { backgroundColor: colors.card, borderRadius: 12 }]}
          onPress={() => router.push("/upgrade")}
          activeOpacity={0.7}
        >
          <Feather name="lock" size={22} color={colors.accent} />
          <View style={styles.lockTextWrap}>
            <Text style={[styles.lockTitle, { color: colors.foreground }]}>Limited AI Coach</Text>
            <Text style={[styles.lockText, { color: colors.mutedForeground }]}>Upgrade to Premium to unlock this feature</Text>
          </View>
          <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
        </TouchableOpacity>
      )}

      {stats.total > 0 ? (
        <>
          <View style={styles.winRateSection}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Win Rate Overview</Text>
            <View style={[styles.winRateBar, { backgroundColor: colors.loss, borderRadius: 8 }]}>
              <View
                style={[
                  styles.winRateFill,
                  {
                    backgroundColor: colors.success,
                    width: `${stats.winRate}%`,
                    borderRadius: 8,
                  },
                ]}
              />
            </View>
            <View style={styles.winRateLabels}>
              <Text style={[styles.winRateLabel, { color: colors.success }]}> {stats.wins}W ({stats.winRate}%)</Text>
              <Text style={[styles.winRateLabel, { color: colors.loss }]}> {stats.losses}L ({stats.total > 0 ? Math.round((stats.losses / stats.total) * 100) : 0}%)</Text>
            </View>
          </View>

          {isPremium ? (
            <>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Session Performance</Text>
              {sessionStats.map((session) => (
                <View key={session.session} style={[styles.sessionRow, { backgroundColor: colors.card, borderRadius: 12 }]}>
                  <Text style={[styles.sessionName, { color: colors.foreground }]}>{session.session}</Text>
                  <View style={styles.sessionRight}>
                    <Text style={[styles.sessionCount, { color: colors.mutedForeground }]}>{session.total} trades</Text>
                    <Text style={[styles.sessionWr, { color: session.winRate >= 50 ? colors.success : colors.loss }]}>{session.winRate}%</Text>
                  </View>
                </View>
              ))}

              {pairStats.length > 0 ? (
                <>
                  <Text style={[styles.sectionTitle, { color: colors.foreground, marginTop: 20 }]}>Pair Performance</Text>
                  {pairStats.map((pair) => (
                    <View key={pair.pair} style={[styles.sessionRow, { backgroundColor: colors.card, borderRadius: 12 }]}>
                      <Text style={[styles.sessionName, { color: colors.foreground }]}>{pair.pair}</Text>
                      <View style={styles.sessionRight}>
                        <Text style={[styles.sessionCount, { color: colors.mutedForeground }]}>{pair.total} trades</Text>
                        <Text style={[styles.sessionWr, { color: pair.winRate >= 50 ? colors.success : colors.loss }]}>{pair.winRate}%</Text>
                      </View>
                    </View>
                  ))}
                </>
              ) : null}
            </>
          ) : (
            <TouchableOpacity
              style={[styles.lockCard, { backgroundColor: colors.card, borderRadius: 12 }]}
              onPress={() => router.push("/upgrade")}
              activeOpacity={0.7}
            >
              <Feather name="bar-chart-2" size={22} color={colors.accent} />
              <View style={styles.lockTextWrap}>
                <Text style={[styles.lockTitle, { color: colors.foreground }]}>Advanced Analytics</Text>
                <Text style={[styles.lockText, { color: colors.mutedForeground }]}>Upgrade to Premium to unlock this feature</Text>
              </View>
              <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
            </TouchableOpacity>
          )}
        </>
      ) : (
        <View style={[styles.emptyState, { backgroundColor: colors.card, borderRadius: 12 }]}> 
          <Feather name="database" size={28} color={colors.mutedForeground} />
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Saved backend analytics will appear after you add trades.</Text>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 20 },
  title: { fontSize: 24, fontFamily: "Inter_700Bold" },
  refreshBtn: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  errorCard: { padding: 12, borderRadius: 10, marginBottom: 12 },
  errorText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  coachCard: { padding: 16, marginBottom: 24 },
  coachHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 },
  coachIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  coachTitleWrap: { flex: 1 },
  coachTitle: { fontSize: 16, fontFamily: "Inter_700Bold" },
  coachSource: { fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 },
  coachText: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 22, marginBottom: 12 },
  mistakesSection: { marginBottom: 12 },
  mistakesLabel: { fontSize: 13, fontFamily: "Inter_600SemiBold", marginBottom: 8 },
  mistakeRow: { flexDirection: "row", alignItems: "flex-start", gap: 8, marginBottom: 6 },
  mistakeText: { fontSize: 13, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 20 },
  ruleBox: { padding: 12, borderRadius: 10, borderWidth: 1 },
  ruleLabel: { fontSize: 12, fontFamily: "Inter_700Bold", marginBottom: 4 },
  ruleText: { fontSize: 14, fontFamily: "Inter_500Medium", lineHeight: 20 },
  winRateSection: { marginBottom: 24 },
  sectionTitle: { fontSize: 18, fontFamily: "Inter_700Bold", marginBottom: 12 },
  winRateBar: { height: 12, overflow: "hidden", marginBottom: 8 },
  winRateFill: { height: "100%" },
  winRateLabels: { flexDirection: "row", justifyContent: "space-between" },
  winRateLabel: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  sessionRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", padding: 16, marginBottom: 8 },
  sessionName: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  sessionRight: { flexDirection: "row", alignItems: "center", gap: 12 },
  sessionCount: { fontSize: 13, fontFamily: "Inter_400Regular" },
  sessionWr: { fontSize: 15, fontFamily: "Inter_700Bold" },
  emptyState: { padding: 28, alignItems: "center", justifyContent: "center", gap: 12 },
  emptyText: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center" },
  lockCard: { flexDirection: "row", alignItems: "center", padding: 16, gap: 12, marginBottom: 16 },
  lockTextWrap: { flex: 1 },
  lockTitle: { fontSize: 15, fontFamily: "Inter_700Bold", marginBottom: 3 },
  lockText: { fontSize: 13, fontFamily: "Inter_400Regular" },
});
