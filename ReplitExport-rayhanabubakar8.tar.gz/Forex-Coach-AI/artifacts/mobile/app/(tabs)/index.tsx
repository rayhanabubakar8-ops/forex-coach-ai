import { Feather } from "@expo/vector-icons";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { StatCard } from "@/components/StatCard";
import { TradeCard } from "@/components/TradeCard";
import { useAuth } from "@/context/AuthContext";
import { useTrades } from "@/context/TradeContext";
import { useColors } from "@/hooks/useColors";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { trades, getStats, deleteTrade } = useTrades();
  const stats = getStats();
  const recentTrades = trades.slice(0, 3);
  const webTop = Platform.OS === "web" ? 67 : 0;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 100,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.greetingRow}>
        <View>
          <Text style={[styles.greeting, { color: colors.mutedForeground }]}>
            Welcome back,
          </Text>
          <Text style={[styles.name, { color: colors.foreground }]}>
            {user?.name ?? "Trader"}
          </Text>
        </View>
        <View
          style={[
            styles.planBadge,
            {
              backgroundColor:
                user?.plan === "premium"
                  ? colors.accent + "20"
                  : colors.muted,
            },
          ]}
        >
          <Text
            style={[
              styles.planText,
              {
                color:
                  user?.plan === "premium"
                    ? colors.accent
                    : colors.mutedForeground,
              },
            ]}
          >
            {user?.plan === "premium" ? "PREMIUM" : "FREE"}
          </Text>
        </View>
      </View>

      <View style={styles.statsGrid}>
        <StatCard
          title="Total Trades"
          value={stats.total}
          icon="bar-chart-2"
          color={colors.primary}
        />
        <StatCard
          title="Win Rate"
          value={`${stats.winRate}%`}
          icon="trending-up"
          color={colors.accent}
        />
      </View>
      <View style={styles.statsGrid}>
        <StatCard
          title="Wins"
          value={stats.wins}
          icon="check-circle"
          color={colors.success}
        />
        <StatCard
          title="Losses"
          value={stats.losses}
          icon="x-circle"
          color={colors.loss}
        />
      </View>

      <View style={styles.sectionHeader}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          Recent Trades
        </Text>
      </View>

      {recentTrades.length === 0 ? (
        <View
          style={[
            styles.emptyState,
            { backgroundColor: colors.card, borderRadius: 12 },
          ]}
        >
          <Feather
            name="book-open"
            size={32}
            color={colors.mutedForeground}
          />
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
            No trades logged yet. Start journaling!
          </Text>
        </View>
      ) : (
        recentTrades.map((trade) => (
          <TradeCard key={trade.id} trade={trade} onDelete={deleteTrade} />
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  greetingRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 24,
  },
  greeting: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
  name: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    marginTop: 2,
  },
  planBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  planText: {
    fontSize: 11,
    fontFamily: "Inter_700Bold",
  },
  statsGrid: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 12,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 12,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  emptyState: {
    padding: 32,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  emptyText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
});
