import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useAuth } from "@/context/AuthContext";
import { useTrades } from "@/context/TradeContext";
import { useColors } from "@/hooks/useColors";

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, logout } = useAuth();
  const { getStats } = useTrades();
  const stats = getStats();
  const webTop = Platform.OS === "web" ? 67 : 0;
  const isPremium = user?.plan === "premium";

  function handleLogout() {
    Alert.alert("Logout", "Are you sure you want to logout?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Logout",
        style: "destructive",
        onPress: () => logout(),
      },
    ]);
  }

  const joinDate = user?.createdAt
    ? new Date(user.createdAt).toLocaleDateString("en-US", {
        month: "long",
        year: "numeric",
      })
    : "N/A";

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 100,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.title, { color: colors.foreground }]}>
        Profile
      </Text>

      <View
        style={[
          styles.profileCard,
          { backgroundColor: colors.card, borderRadius: 12 },
        ]}
      >
        <View
          style={[styles.avatar, { backgroundColor: colors.primary + "20" }]}
        >
          <Text style={[styles.avatarText, { color: colors.primary }]}>
            {user?.name?.charAt(0)?.toUpperCase() ?? "T"}
          </Text>
        </View>
        <Text style={[styles.userName, { color: colors.foreground }]}>
          {user?.name ?? "Trader"}
        </Text>
        <Text style={[styles.userEmail, { color: colors.mutedForeground }]}>
          {user?.email ?? ""}
        </Text>
        <View
          style={[
            styles.planChip,
            {
              backgroundColor:
                isPremium
                  ? colors.accent + "20"
                  : colors.muted,
            },
          ]}
        >
          <Text
            style={[
              styles.planChipText,
              {
                color:
                  isPremium
                    ? colors.accent
                    : colors.mutedForeground,
              },
            ]}
          >
            {isPremium ? "Premium Plan" : "Free Plan"}
          </Text>
        </View>
      </View>

      <View
        style={[
          styles.statsCard,
          { backgroundColor: colors.card, borderRadius: 12 },
        ]}
      >
        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.foreground }]}>
              {stats.total}
            </Text>
            <Text
              style={[styles.statLabel, { color: colors.mutedForeground }]}
            >
              Total Trades
            </Text>
          </View>
          <View
            style={[styles.statDivider, { backgroundColor: colors.border }]}
          />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.primary }]}>
              {stats.winRate}%
            </Text>
            <Text
              style={[styles.statLabel, { color: colors.mutedForeground }]}
            >
              Win Rate
            </Text>
          </View>
          <View
            style={[styles.statDivider, { backgroundColor: colors.border }]}
          />
          <View style={styles.statItem}>
            <Text style={[styles.statValue, { color: colors.foreground }]}>
              {joinDate}
            </Text>
            <Text
              style={[styles.statLabel, { color: colors.mutedForeground }]}
            >
              Joined
            </Text>
          </View>
        </View>
      </View>

      {!isPremium && (
        <TouchableOpacity
          style={[
            styles.upgradeBtn,
            { backgroundColor: colors.accent, borderRadius: 12 },
          ]}
          onPress={() => router.push("/upgrade")}
          activeOpacity={0.7}
        >
          <Feather name="star" size={18} color={colors.accentForeground} />
          <Text
            style={[styles.upgradeBtnText, { color: colors.accentForeground }]}
          >
            Upgrade to Premium
          </Text>
        </TouchableOpacity>
      )}

      <View style={[styles.featuresCard, { backgroundColor: colors.card, borderRadius: 12 }]}>
        <Text style={[styles.featuresTitle, { color: colors.foreground }]}>Premium Features</Text>
        {[
          "Prop firm mode",
          "Advanced analytics",
          "Unlimited AI coach",
          "CSV trade upload",
          "Trading University full access",
        ].map((feature) => (
          <TouchableOpacity
            key={feature}
            style={styles.featureRow}
            onPress={() => {
              if (!isPremium) router.push("/upgrade");
            }}
            activeOpacity={0.7}
          >
            <Feather
              name={isPremium ? "check-circle" : "lock"}
              size={18}
              color={isPremium ? colors.success : colors.accent}
            />
            <View style={styles.featureTextWrap}>
              <Text style={[styles.featureName, { color: colors.foreground }]}>{feature}</Text>
              {!isPremium && (
                <Text style={[styles.featureLockText, { color: colors.mutedForeground }]}>
                  Upgrade to Premium to unlock this feature
                </Text>
              )}
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={[
          styles.menuItem,
          { backgroundColor: colors.card, borderRadius: 12 },
        ]}
        onPress={handleLogout}
        activeOpacity={0.7}
      >
        <Feather name="log-out" size={20} color={colors.destructive} />
        <Text style={[styles.menuItemText, { color: colors.destructive }]}>
          Logout
        </Text>
        <Feather
          name="chevron-right"
          size={18}
          color={colors.mutedForeground}
        />
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    marginBottom: 20,
  },
  profileCard: {
    padding: 24,
    alignItems: "center",
    marginBottom: 16,
  },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  avatarText: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
  },
  userName: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    marginBottom: 12,
  },
  planChip: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
  },
  planChipText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  statsCard: {
    padding: 16,
    marginBottom: 16,
  },
  statsRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  statItem: {
    flex: 1,
    alignItems: "center",
  },
  statValue: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  statDivider: {
    width: 1,
    height: 40,
  },
  upgradeBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
    gap: 8,
    marginBottom: 16,
  },
  upgradeBtnText: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  menuItem: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    gap: 12,
    marginBottom: 8,
  },
  menuItemText: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
    flex: 1,
  },
  featuresCard: {
    padding: 16,
    marginBottom: 16,
  },
  featuresTitle: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
    marginBottom: 12,
  },
  featureRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 10,
    paddingVertical: 10,
  },
  featureTextWrap: {
    flex: 1,
  },
  featureName: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  featureLockText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
});
