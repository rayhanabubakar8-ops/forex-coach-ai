import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { LessonCard } from "@/components/LessonCard";
import { useAuth } from "@/context/AuthContext";
import { lessons } from "@/data/lessons";
import { useColors } from "@/hooks/useColors";

const levels = ["Beginner", "Intermediate", "Advanced"] as const;

export default function UniversityScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [activeLevel, setActiveLevel] =
    useState<(typeof levels)[number]>("Beginner");
  const isPremium = user?.plan === "premium";
  const webTop = Platform.OS === "web" ? 67 : 0;

  const filtered = lessons.filter((l) => l.level === activeLevel);

  function handleLessonPress(lessonId: string) {
    const lesson = lessons.find((l) => l.id === lessonId);
    if (!lesson) return;
    if (lesson.level !== "Beginner" && !isPremium) {
      router.push("/upgrade");
      return;
    }
    router.push({ pathname: "/lesson/[id]", params: { id: lessonId } });
  }

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 100,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.title, { color: colors.foreground }]}>
        Trading University
      </Text>

      {!isPremium && (
        <TouchableOpacity
          style={[
            styles.premiumBanner,
            { backgroundColor: colors.accent + "15", borderColor: colors.accent + "30" },
          ]}
          onPress={() => router.push("/upgrade")}
          activeOpacity={0.7}
        >
          <Feather name="star" size={18} color={colors.accent} />
          <View style={styles.bannerText}>
            <Text style={[styles.bannerTitle, { color: colors.accent }]}>
              Unlock All Lessons
            </Text>
            <Text
              style={[
                styles.bannerSubtitle,
                { color: colors.mutedForeground },
              ]}
            >
              Upgrade to Premium to unlock this feature
            </Text>
          </View>
          <Feather
            name="chevron-right"
            size={18}
            color={colors.accent}
          />
        </TouchableOpacity>
      )}

      <View style={styles.levelTabs}>
        {levels.map((level) => (
          <TouchableOpacity
            key={level}
            style={[
              styles.levelTab,
              {
                backgroundColor:
                  activeLevel === level ? colors.primary + "20" : colors.card,
                borderRadius: 8,
              },
            ]}
            onPress={() => setActiveLevel(level)}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.levelText,
                {
                  color:
                    activeLevel === level
                      ? colors.primary
                      : colors.mutedForeground,
                },
              ]}
            >
              {level}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {filtered.map((lesson) => (
        <LessonCard
          key={lesson.id}
          title={lesson.title}
          description={lesson.description}
          level={lesson.level}
          locked={lesson.level !== "Beginner" && !isPremium}
          onPress={() => handleLessonPress(lesson.id)}
        />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    marginBottom: 16,
  },
  premiumBanner: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 20,
    gap: 12,
  },
  bannerText: {
    flex: 1,
  },
  bannerTitle: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  bannerSubtitle: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginTop: 2,
  },
  levelTabs: {
    flexDirection: "row",
    gap: 8,
    marginBottom: 16,
  },
  levelTab: {
    flex: 1,
    paddingVertical: 10,
    alignItems: "center",
  },
  levelText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
});
