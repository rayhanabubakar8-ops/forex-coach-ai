import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useTrades } from "@/context/TradeContext";
import { useColors } from "@/hooks/useColors";

const pairs = [
  "EURUSD",
  "GBPUSD",
  "USDJPY",
  "USDCHF",
  "AUDUSD",
  "NZDUSD",
  "USDCAD",
  "XAUUSD",
  "GBPJPY",
  "EURJPY",
];
const sessions = ["Asia", "London", "New York"] as const;
const results = ["win", "loss"] as const;

export default function AddTradeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addTrade } = useTrades();
  const webTop = Platform.OS === "web" ? 67 : 0;

  const [pair, setPair] = useState(pairs[0]);
  const [entryPrice, setEntryPrice] = useState("");
  const [stopLoss, setStopLoss] = useState("");
  const [takeProfit, setTakeProfit] = useState("");
  const [lotSize, setLotSize] = useState("");
  const [result, setResult] = useState<"win" | "loss">("win");
  const [session, setSession] = useState<(typeof sessions)[number]>("London");
  const [notes, setNotes] = useState("");

  async function handleSubmit() {
    if (!entryPrice || !stopLoss || !takeProfit || !lotSize) {
      Alert.alert("Missing Fields", "Please fill in all required fields.");
      return;
    }
    await addTrade({
      pair,
      entryPrice,
      stopLoss,
      takeProfit,
      lotSize,
      result,
      session,
      notes,
    });
    if (Platform.OS !== "web") {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
    router.back();
  }

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 40,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} hitSlop={8}>
          <Feather name="x" size={24} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.foreground }]}>
          New Trade
        </Text>
        <View style={{ width: 24 }} />
      </View>

      <Text style={[styles.label, { color: colors.mutedForeground }]}>
        Currency Pair
      </Text>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.pairScroll}
      >
        {pairs.map((p) => (
          <TouchableOpacity
            key={p}
            style={[
              styles.chip,
              {
                backgroundColor:
                  pair === p ? colors.primary + "20" : colors.card,
                borderRadius: 8,
              },
            ]}
            onPress={() => setPair(p)}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.chipText,
                {
                  color: pair === p ? colors.primary : colors.mutedForeground,
                },
              ]}
            >
              {p}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <Text style={[styles.label, { color: colors.mutedForeground }]}>
        Entry Price *
      </Text>
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: colors.card,
            color: colors.foreground,
            borderColor: colors.border,
          },
        ]}
        value={entryPrice}
        onChangeText={setEntryPrice}
        placeholder="1.08500"
        placeholderTextColor={colors.mutedForeground}
        keyboardType="decimal-pad"
      />

      <View style={styles.row}>
        <View style={styles.halfField}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            Stop Loss *
          </Text>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.card,
                color: colors.foreground,
                borderColor: colors.border,
              },
            ]}
            value={stopLoss}
            onChangeText={setStopLoss}
            placeholder="1.08300"
            placeholderTextColor={colors.mutedForeground}
            keyboardType="decimal-pad"
          />
        </View>
        <View style={styles.halfField}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            Take Profit *
          </Text>
          <TextInput
            style={[
              styles.input,
              {
                backgroundColor: colors.card,
                color: colors.foreground,
                borderColor: colors.border,
              },
            ]}
            value={takeProfit}
            onChangeText={setTakeProfit}
            placeholder="1.08900"
            placeholderTextColor={colors.mutedForeground}
            keyboardType="decimal-pad"
          />
        </View>
      </View>

      <Text style={[styles.label, { color: colors.mutedForeground }]}>
        Lot Size *
      </Text>
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: colors.card,
            color: colors.foreground,
            borderColor: colors.border,
          },
        ]}
        value={lotSize}
        onChangeText={setLotSize}
        placeholder="0.01"
        placeholderTextColor={colors.mutedForeground}
        keyboardType="decimal-pad"
      />

      <Text style={[styles.label, { color: colors.mutedForeground }]}>
        Result
      </Text>
      <View style={styles.resultRow}>
        {results.map((r) => (
          <TouchableOpacity
            key={r}
            style={[
              styles.resultChip,
              {
                backgroundColor:
                  result === r
                    ? r === "win"
                      ? colors.success + "20"
                      : colors.loss + "20"
                    : colors.card,
                borderRadius: 10,
                flex: 1,
              },
            ]}
            onPress={() => setResult(r)}
            activeOpacity={0.7}
          >
            <Feather
              name={r === "win" ? "trending-up" : "trending-down"}
              size={18}
              color={
                result === r
                  ? r === "win"
                    ? colors.success
                    : colors.loss
                  : colors.mutedForeground
              }
            />
            <Text
              style={[
                styles.resultText,
                {
                  color:
                    result === r
                      ? r === "win"
                        ? colors.success
                        : colors.loss
                      : colors.mutedForeground,
                },
              ]}
            >
              {r.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={[styles.label, { color: colors.mutedForeground }]}>
        Session
      </Text>
      <View style={styles.sessionRow}>
        {sessions.map((s) => (
          <TouchableOpacity
            key={s}
            style={[
              styles.sessionChip,
              {
                backgroundColor:
                  session === s ? colors.primary + "20" : colors.card,
                borderRadius: 8,
                flex: 1,
              },
            ]}
            onPress={() => setSession(s)}
            activeOpacity={0.7}
          >
            <Text
              style={[
                styles.sessionText,
                {
                  color:
                    session === s ? colors.primary : colors.mutedForeground,
                },
              ]}
            >
              {s}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={[styles.label, { color: colors.mutedForeground }]}>
        Notes
      </Text>
      <TextInput
        style={[
          styles.input,
          styles.notesInput,
          {
            backgroundColor: colors.card,
            color: colors.foreground,
            borderColor: colors.border,
          },
        ]}
        value={notes}
        onChangeText={setNotes}
        placeholder="Trading notes..."
        placeholderTextColor={colors.mutedForeground}
        multiline
        numberOfLines={3}
        textAlignVertical="top"
      />

      <TouchableOpacity
        style={[
          styles.submitBtn,
          { backgroundColor: colors.primary, borderRadius: 12 },
        ]}
        onPress={handleSubmit}
        activeOpacity={0.7}
      >
        <Text
          style={[styles.submitText, { color: colors.primaryForeground }]}
        >
          Log Trade
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 24,
  },
  title: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
  },
  label: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 8,
    marginTop: 16,
  },
  pairScroll: {
    flexGrow: 0,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginRight: 8,
  },
  chipText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  input: {
    padding: 14,
    borderRadius: 10,
    borderWidth: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
  },
  row: {
    flexDirection: "row",
    gap: 12,
  },
  halfField: {
    flex: 1,
  },
  resultRow: {
    flexDirection: "row",
    gap: 12,
  },
  resultChip: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 14,
    gap: 8,
  },
  resultText: {
    fontSize: 14,
    fontFamily: "Inter_700Bold",
  },
  sessionRow: {
    flexDirection: "row",
    gap: 8,
  },
  sessionChip: {
    paddingVertical: 12,
    alignItems: "center",
  },
  sessionText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  notesInput: {
    minHeight: 80,
  },
  submitBtn: {
    padding: 16,
    alignItems: "center",
    marginTop: 24,
  },
  submitText: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
});
