import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { lessons } from "@/data/lessons";
import { useColors } from "@/hooks/useColors";

const levelColors: Record<string, string> = {
  Beginner: "#00E676",
  Intermediate: "#FFD700",
  Advanced: "#FF5252",
};

export default function LessonScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const lesson = lessons.find((l) => l.id === id);
  const webTop = Platform.OS === "web" ? 67 : 0;

  if (!lesson) {
    return (
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.background,
            justifyContent: "center",
            alignItems: "center",
          },
        ]}
      >
        <Text style={{ color: colors.foreground }}>Lesson not found</Text>
      </View>
    );
  }

  const levelColor = levelColors[lesson.level] ?? colors.primary;

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{
        paddingTop: insets.top + 16 + webTop,
        paddingBottom: insets.bottom + 40,
        paddingHorizontal: 16,
      }}
      showsVerticalScrollIndicator={false}
    >
      <TouchableOpacity
        style={styles.backBtn}
        onPress={() => router.back()}
        hitSlop={8}
      >
        <Feather name="arrow-left" size={24} color={colors.foreground} />
      </TouchableOpacity>

      <View
        style={[
          styles.levelBadge,
          { backgroundColor: levelColor + "20" },
        ]}
      >
        <Text style={[styles.levelText, { color: levelColor }]}>
          {lesson.level}
        </Text>
      </View>

      <Text style={[styles.title, { color: colors.foreground }]}>
        {lesson.title}
      </Text>
      <Text style={[styles.description, { color: colors.mutedForeground }]}>
        {lesson.description}
      </Text>

      <View
        style={[
          styles.contentCard,
          { backgroundColor: colors.card, borderRadius: 12 },
        ]}
      >
        <Text style={[styles.content, { color: colors.foreground }]}>
          {lesson.content}
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backBtn: {
    marginBottom: 16,
  },
  levelBadge: {
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
    marginBottom: 12,
  },
  levelText: {
    fontSize: 12,
    fontFamily: "Inter_700Bold",
  },
  title: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    marginBottom: 8,
  },
  description: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    lineHeight: 22,
    marginBottom: 24,
  },
  contentCard: {
    padding: 20,
  },
  content: {
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    lineHeight: 24,
  },
});
