# TradeMind AI

## Overview

A forex trading journal and AI coaching application built with Expo (React Native) and a real Node.js backend. The app helps traders become disciplined and profitable using persistent trade journaling, backend analytics, account risk tracking, and AI-powered trading coaching.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **Frontend**: Expo (React Native), also runs as a web application through Expo Web
- **Backend**: Express 5 API server
- **Data storage**: SQLite database stored at `data/trademind.sqlite`
- **AI coaching**: OpenAI-compatible AI integration via backend route with fast rule-based fallback
- **Navigation**: Expo Router
- **Local account/session storage**: AsyncStorage for user profile/session state

## Backend Routes

The API server mounts routes under `/api`:

- `GET /api/health` — plain-text health check returning `OK`
- `GET /api/healthz` — JSON health check returning `{ "status": "ok" }`
- `POST /api/add_trade` — validates and saves a journal trade permanently in SQLite
- `GET /api/get_trades?userId=...` — loads saved journal trades for a user
- `GET /api/analytics?userId=...` — returns journal stats, session stats, pair stats, and coach advice
- `DELETE /api/delete_trade/:id?userId=...` — deletes a saved journal trade
- `POST /api/create_account` — creates a personal or prop trading account with balance, daily loss limit, max drawdown, and profit target
- `GET /api/accounts` — lists trading accounts
- `POST /api/add_account_trade` — records PnL for a trading account
- `GET /api/account_trades/:accountId` — lists PnL trades for a trading account
- `GET /api/analytics/:accountId` — returns account balance, equity, total PnL, daily PnL, drawdown, and risk status

## App Structure

### Screens (Tabs)
- **Home** - Dashboard with backend-loaded stats and recent saved trades
- **Journal** - Full trade journal with filtering and backend-backed add/delete actions
- **Analytics** - Backend analytics plus AI Trading Coach advice from saved trades
- **University** - Trading lessons (Beginner free, Intermediate/Advanced premium-locked)
- **Profile** - User info, stats summary, upgrade to premium, logout

### Additional Screens
- **Root Redirect** - Opens login or tabs so the preview never stays blank at `/`
- **Login/Signup** - Local account/session flow
- **Add Trade** - Modal connected to `POST /api/add_trade`
- **Lesson Detail** - Full lesson content view
- **Upgrade** - Premium upgrade with payment proof upload (bank/OPay)

### Key Features
- Dark mode UI with navy/green/gold trading design
- Permanent trade persistence in SQLite
- Automatic loading of saved trades when the app opens
- Analytics refreshes from backend-saved trades
- AI Trading Coach analyzes real saved trade data and falls back quickly if AI is unavailable or slow
- Explicit backend API base URL configured for Expo preview/native access
- Account risk analytics for personal and prop accounts, including daily loss limit, max drawdown, profit target, equity, and status
- Payment proof upload for local premium upgrade flow

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/mobile run dev` — run mobile/web dev server
- `pnpm --filter @workspace/api-server run dev` — run backend API server
